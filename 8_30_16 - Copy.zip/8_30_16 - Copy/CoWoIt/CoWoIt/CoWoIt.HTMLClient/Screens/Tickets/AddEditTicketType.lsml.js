﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditTicketType.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.TicketType.deleteEntity();
    myapp.commitChanges();
};