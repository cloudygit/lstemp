﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditTicket.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.Ticket.deleteEntity();
    myapp.commitChanges();
};