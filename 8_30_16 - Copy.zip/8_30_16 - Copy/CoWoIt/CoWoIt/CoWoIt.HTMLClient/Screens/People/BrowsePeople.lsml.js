﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.BrowsePeople.DeletePerson_execute = function (screen) {
    screen.getPeople().then(function (people) {
        people.deleteSelected();
        myapp.commitChanges();
    });
};
