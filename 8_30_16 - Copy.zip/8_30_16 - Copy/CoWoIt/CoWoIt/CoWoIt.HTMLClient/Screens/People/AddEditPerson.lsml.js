﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditPerson.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.Person.deleteEntity();
    myapp.commitChanges();
};