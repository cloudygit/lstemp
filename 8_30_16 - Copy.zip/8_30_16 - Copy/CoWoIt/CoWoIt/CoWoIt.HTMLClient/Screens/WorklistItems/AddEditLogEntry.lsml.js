﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditLogEntry.created = function (screen) {
    // Write code here.

};
myapp.AddEditLogEntry.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.LogEntry.deleteEntity();
    myapp.commitChanges();
};