﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.NewWorklistItem.ShowStep2_execute = function (screen) {
    var hasError = false;
    var contentItem;

    if (screen.WorklistItem.Organization == null) {
        screen.WorklistItem.Organization = null;

        contentItem = screen.findContentItem("Organization");
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Organization, "This field is required.")
        ];
        
        hasError = true;
    }



    if (screen.WorklistItem.Name == null) {
        screen.WorklistItem.Name = null;
        hasError = true;
    }

    contentItem = screen.findContentItem("Name");


    if (contentItem.validationResults.length > 0) {
        hasError = true;
    }

    contentItem = screen.findContentItem("Description");

    if (contentItem.validationResults.length > 0) {
        hasError = true;
    }
    
    if (!hasError) {
        screen.showTab("Step2");
        screen.details.displayName = "Step 2";
    }

};

myapp.NewWorklistItem.ShowStep3_execute = function (screen) {
    var hasError = false;

    if (screen.WorklistItem.Area == null) {
        screen.WorklistItem.Area = null;
        contentItem = screen.findContentItem("Area");
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Area, "This field is required.")
        ];
        hasError = true;
    }

    if (screen.WorklistItem.Status == null) {
        screen.WorklistItem.Status= null;
        contentItem = screen.findContentItem("Status");
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Area, "This field is required.")
        ];
        hasError = true;
    }

    if (screen.WorklistItem.Environment == null) {
        screen.WorklistItem.Environment = null;
        contentItem = screen.findContentItem("Environment");
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Environment, "This field is required.")
        ];
        hasError = true;
    }

    if (screen.WorklistItem.Person == null) {
        screen.WorklistItem.Person = null;
        contentItem = screen.findContentItem("Person");
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Person, "This field is required.")
        ];
        hasError = true;
    }



    if (!hasError) {
        screen.showTab("Step3");
        screen.details.displayName = "Step 3";
    }
};

myapp.NewWorklistItem.Finish_execute = function (screen) {
    myapp.commitChanges();
};





myapp.NewWorklistItem.AddEnviro_execute = function (screen) {
    myapp.showAddEditEnvironment(null,
    {
        beforeShown: function(addNewScreen) {
            addNewScreen.WorklistItem = screen.WorklistItem.Organization;
        }
    });

};