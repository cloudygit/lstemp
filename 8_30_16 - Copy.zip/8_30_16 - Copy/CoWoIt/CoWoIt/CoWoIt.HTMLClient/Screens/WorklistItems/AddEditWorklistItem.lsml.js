﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditWorklistItem.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.WorklistItem.deleteEntity();
    myapp.commitChanges();
};