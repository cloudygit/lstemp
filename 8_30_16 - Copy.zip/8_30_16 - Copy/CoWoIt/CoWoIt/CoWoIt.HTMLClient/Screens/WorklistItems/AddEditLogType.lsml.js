﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditLogType.Name_postRender = function (element, contentItem) {
    // Write code here.
    $(element).parent().css('color', 'red'); $(element).parent().find("label")[0].innerHTML += " *"


};
myapp.AddEditLogType.DeleteThis_execute = function (screen) {
    screen.LogType.deleteEntity();
    myapp.commitChanges();
};