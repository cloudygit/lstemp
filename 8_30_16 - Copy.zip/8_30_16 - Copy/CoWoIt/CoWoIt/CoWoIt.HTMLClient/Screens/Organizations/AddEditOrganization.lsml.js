﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditOrganization.Name_postRender = function (element, contentItem) {
    $(element).parent().css('color', 'red'); $(element).parent().find("label")[0].innerHTML += " *"
};
myapp.AddEditOrganization.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.Organization.deleteEntity();
    myapp.commitChanges();
};