﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditArea.Name_postRender = function (element, contentItem) {
    $(element).parent().css('color', 'red'); $(element).parent().find("label")[0].innerHTML += " *"
};
myapp.AddEditArea.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.Area.deleteEntity();
    myapp.commitChanges();
};