﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditStatus.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.Status.deleteEntity();
    myapp.commitChanges();
};