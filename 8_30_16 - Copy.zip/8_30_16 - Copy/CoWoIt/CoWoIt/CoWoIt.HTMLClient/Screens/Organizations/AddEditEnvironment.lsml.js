﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditEnvironment.Name_postRender = function (element, contentItem) {
    $(element).parent().css('color', 'red'); $(element).parent().find("label")[0].innerHTML += " *"
};
myapp.AddEditEnvironment.DeleteThis_execute = function (screen) {
    // Write code here.
    screen.Environment.deleteEntity();
    myapp.commitChanges();
};