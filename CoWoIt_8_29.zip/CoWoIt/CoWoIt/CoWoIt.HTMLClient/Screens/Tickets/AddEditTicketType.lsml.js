﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditTicketType.Name_postRender = function (element, contentItem) {
    // Write code here.
    $(element).parent().css('color', 'red'); $(element).parent().find("label")[0].innerHTML += " *"


};