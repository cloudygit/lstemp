﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

