﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.BrowseOrganizations.DeleteOrg_execute = function (screen) {
    screen.getOrganizations().then(function (orgs) {
        orgs.deleteSelected();
    });
};