﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditArea.Name_postRender = function (element, contentItem) {
    $(element).parent().css('color', 'red'); $(element).parent().find("label")[0].innerHTML += " *"
};