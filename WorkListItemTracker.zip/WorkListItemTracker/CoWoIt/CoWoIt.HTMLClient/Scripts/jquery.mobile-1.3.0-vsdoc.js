/*
* This file is intentionally blank to avoid running the real
* jQuery Mobile library code when processing for intellisense.
*/
