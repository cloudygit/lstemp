﻿/// <reference path="viewModel.js" />

(function (lightSwitchApplication) {

    var $element = document.createElement("div");

    lightSwitchApplication.AddEditArea.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditArea
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.AddEditArea,
            value: lightSwitchApplication.AddEditArea
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.AddEditArea,
            value: lightSwitchApplication.Area
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.Area,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditArea
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditArea, {
        /// <field>
        /// Called when a new AddEditArea screen is created.
        /// <br/>created(msls.application.AddEditArea screen)
        /// </field>
        created: [lightSwitchApplication.AddEditArea],
        /// <field>
        /// Called before changes on an active AddEditArea screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditArea screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditArea],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("Name"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("right"); }]
    });

    lightSwitchApplication.AddEditEnvironment.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditEnvironment
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.AddEditEnvironment,
            value: lightSwitchApplication.AddEditEnvironment
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.AddEditEnvironment,
            value: lightSwitchApplication.Environment
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Organization
        },
        RowTemplate: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate",
            _$parentName: "Organization",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditEnvironment
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditEnvironment, {
        /// <field>
        /// Called when a new AddEditEnvironment screen is created.
        /// <br/>created(msls.application.AddEditEnvironment screen)
        /// </field>
        created: [lightSwitchApplication.AddEditEnvironment],
        /// <field>
        /// Called before changes on an active AddEditEnvironment screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditEnvironment screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditEnvironment],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("Name"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("right"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("Organization"); }],
        /// <field>
        /// Called after the RowTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("RowTemplate"); }]
    });

    lightSwitchApplication.AddEditOrganization.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditOrganization
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditOrganization,
            data: lightSwitchApplication.AddEditOrganization,
            value: lightSwitchApplication.AddEditOrganization
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditOrganization,
            data: lightSwitchApplication.AddEditOrganization,
            value: lightSwitchApplication.Organization
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditOrganization,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditOrganization,
            data: lightSwitchApplication.Organization,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditOrganization,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditOrganization
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditOrganization, {
        /// <field>
        /// Called when a new AddEditOrganization screen is created.
        /// <br/>created(msls.application.AddEditOrganization screen)
        /// </field>
        created: [lightSwitchApplication.AddEditOrganization],
        /// <field>
        /// Called before changes on an active AddEditOrganization screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditOrganization screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditOrganization],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrganization().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrganization().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrganization().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrganization().findContentItem("Name"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrganization().findContentItem("right"); }]
    });

    lightSwitchApplication.AddEditPerson.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditPerson
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.AddEditPerson,
            value: lightSwitchApplication.AddEditPerson
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.AddEditPerson,
            value: lightSwitchApplication.Person
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        DisplayName: {
            _$class: msls.ContentItem,
            _$name: "DisplayName",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.Person,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditPerson
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditPerson, {
        /// <field>
        /// Called when a new AddEditPerson screen is created.
        /// <br/>created(msls.application.AddEditPerson screen)
        /// </field>
        created: [lightSwitchApplication.AddEditPerson],
        /// <field>
        /// Called before changes on an active AddEditPerson screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditPerson screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditPerson],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("left"); }],
        /// <field>
        /// Called after the DisplayName content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DisplayName_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("DisplayName"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("right"); }]
    });

    lightSwitchApplication.BrowseOrganizations.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseOrganizations
        },
        OrganizationList: {
            _$class: msls.ContentItem,
            _$name: "OrganizationList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseOrganizations,
            data: lightSwitchApplication.BrowseOrganizations,
            value: lightSwitchApplication.BrowseOrganizations
        },
        Organizations: {
            _$class: msls.ContentItem,
            _$name: "Organizations",
            _$parentName: "OrganizationList",
            screen: lightSwitchApplication.BrowseOrganizations,
            data: lightSwitchApplication.BrowseOrganizations,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseOrganizations,
                _$entry: {
                    elementType: lightSwitchApplication.Organization
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "Organizations",
            screen: lightSwitchApplication.BrowseOrganizations,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseOrganizations,
            data: lightSwitchApplication.Organization,
            value: String
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseOrganizations,
            data: lightSwitchApplication.Organization,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseOrganizations,
            data: lightSwitchApplication.Organization,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseOrganizations
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseOrganizations, {
        /// <field>
        /// Called when a new BrowseOrganizations screen is created.
        /// <br/>created(msls.application.BrowseOrganizations screen)
        /// </field>
        created: [lightSwitchApplication.BrowseOrganizations],
        /// <field>
        /// Called before changes on an active BrowseOrganizations screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseOrganizations screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseOrganizations],
        /// <field>
        /// Called to determine if the DeleteOrg method can be executed.
        /// <br/>canExecute(msls.application.BrowseOrganizations screen)
        /// </field>
        DeleteOrg_canExecute: [lightSwitchApplication.BrowseOrganizations],
        /// <field>
        /// Called to execute the DeleteOrg method.
        /// <br/>execute(msls.application.BrowseOrganizations screen)
        /// </field>
        DeleteOrg_execute: [lightSwitchApplication.BrowseOrganizations],
        /// <field>
        /// Called after the OrganizationList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        OrganizationList_postRender: [$element, function () { return new lightSwitchApplication.BrowseOrganizations().findContentItem("OrganizationList"); }],
        /// <field>
        /// Called after the Organizations content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organizations_postRender: [$element, function () { return new lightSwitchApplication.BrowseOrganizations().findContentItem("Organizations"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseOrganizations().findContentItem("rows"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.BrowseOrganizations().findContentItem("Name"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.BrowseOrganizations().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.BrowseOrganizations().findContentItem("Created"); }]
    });

    lightSwitchApplication.ViewOrganization.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewOrganization
        },
        Group: {
            _$class: msls.ContentItem,
            _$name: "Group",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.ViewOrganization,
            value: lightSwitchApplication.ViewOrganization
        },
        WorklistItems: {
            _$class: msls.ContentItem,
            _$name: "WorklistItems",
            _$parentName: "Group",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.ViewOrganization,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewOrganization,
                _$entry: {
                    elementType: lightSwitchApplication.WorklistItem
                }
            }
        },
        WorklistItemsTemplate: {
            _$class: msls.ContentItem,
            _$name: "WorklistItemsTemplate",
            _$parentName: "WorklistItems",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name2: {
            _$class: msls.ContentItem,
            _$name: "Name2",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Description1: {
            _$class: msls.ContentItem,
            _$name: "Description1",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        Status: {
            _$class: msls.ContentItem,
            _$name: "Status",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Status
        },
        StartDate: {
            _$class: msls.ContentItem,
            _$name: "StartDate",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        EndDate: {
            _$class: msls.ContentItem,
            _$name: "EndDate",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        CreatedBy1: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy1",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Created1: {
            _$class: msls.ContentItem,
            _$name: "Created1",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        ModifiedBy1: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy1",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Modified1: {
            _$class: msls.ContentItem,
            _$name: "Modified1",
            _$parentName: "WorklistItemsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        Group2: {
            _$class: msls.ContentItem,
            _$name: "Group2",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.ViewOrganization,
            value: lightSwitchApplication.ViewOrganization
        },
        Environments: {
            _$class: msls.ContentItem,
            _$name: "Environments",
            _$parentName: "Group2",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.ViewOrganization,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewOrganization,
                _$entry: {
                    elementType: lightSwitchApplication.Environment
                }
            }
        },
        EnvironmentsTemplate: {
            _$class: msls.ContentItem,
            _$name: "EnvironmentsTemplate",
            _$parentName: "Environments",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "EnvironmentsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: String
        },
        Organization2: {
            _$class: msls.ContentItem,
            _$name: "Organization2",
            _$parentName: "EnvironmentsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Organization
        },
        CreatedBy2: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy2",
            _$parentName: "EnvironmentsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: String
        },
        Created2: {
            _$class: msls.ContentItem,
            _$name: "Created2",
            _$parentName: "EnvironmentsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: Date
        },
        ModifiedBy2: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy2",
            _$parentName: "EnvironmentsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: String
        },
        Modified2: {
            _$class: msls.ContentItem,
            _$name: "Modified2",
            _$parentName: "EnvironmentsTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Environment,
            value: Date
        },
        Group3: {
            _$class: msls.ContentItem,
            _$name: "Group3",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.ViewOrganization,
            value: lightSwitchApplication.ViewOrganization
        },
        Areas: {
            _$class: msls.ContentItem,
            _$name: "Areas",
            _$parentName: "Group3",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.ViewOrganization,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewOrganization,
                _$entry: {
                    elementType: lightSwitchApplication.Area
                }
            }
        },
        AreasTemplate: {
            _$class: msls.ContentItem,
            _$name: "AreasTemplate",
            _$parentName: "Areas",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        Name3: {
            _$class: msls.ContentItem,
            _$name: "Name3",
            _$parentName: "AreasTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: String
        },
        Organization4: {
            _$class: msls.ContentItem,
            _$name: "Organization4",
            _$parentName: "AreasTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Organization
        },
        CreatedBy3: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy3",
            _$parentName: "AreasTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: String
        },
        Created3: {
            _$class: msls.ContentItem,
            _$name: "Created3",
            _$parentName: "AreasTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: Date
        },
        ModifiedBy3: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy3",
            _$parentName: "AreasTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: String
        },
        Modified3: {
            _$class: msls.ContentItem,
            _$name: "Modified3",
            _$parentName: "AreasTemplate",
            screen: lightSwitchApplication.ViewOrganization,
            data: lightSwitchApplication.Area,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewOrganization
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewOrganization, {
        /// <field>
        /// Called when a new ViewOrganization screen is created.
        /// <br/>created(msls.application.ViewOrganization screen)
        /// </field>
        created: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called before changes on an active ViewOrganization screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewOrganization screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called to determine if the DeleteArea method can be executed.
        /// <br/>canExecute(msls.application.ViewOrganization screen)
        /// </field>
        DeleteArea_canExecute: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called to execute the DeleteArea method.
        /// <br/>execute(msls.application.ViewOrganization screen)
        /// </field>
        DeleteArea_execute: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called to determine if the DeleteEnvironment method can be executed.
        /// <br/>canExecute(msls.application.ViewOrganization screen)
        /// </field>
        DeleteEnvironment_canExecute: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called to execute the DeleteEnvironment method.
        /// <br/>execute(msls.application.ViewOrganization screen)
        /// </field>
        DeleteEnvironment_execute: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called to determine if the DeletePerson method can be executed.
        /// <br/>canExecute(msls.application.ViewOrganization screen)
        /// </field>
        DeletePerson_canExecute: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called to execute the DeletePerson method.
        /// <br/>execute(msls.application.ViewOrganization screen)
        /// </field>
        DeletePerson_execute: [lightSwitchApplication.ViewOrganization],
        /// <field>
        /// Called after the Group content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Group"); }],
        /// <field>
        /// Called after the WorklistItems content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItems_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("WorklistItems"); }],
        /// <field>
        /// Called after the WorklistItemsTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItemsTemplate_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("WorklistItemsTemplate"); }],
        /// <field>
        /// Called after the Name2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Name2"); }],
        /// <field>
        /// Called after the Description1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Description1"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Environment"); }],
        /// <field>
        /// Called after the Status content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Status_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Status"); }],
        /// <field>
        /// Called after the StartDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StartDate_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("StartDate"); }],
        /// <field>
        /// Called after the EndDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EndDate_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("EndDate"); }],
        /// <field>
        /// Called after the CreatedBy1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("CreatedBy1"); }],
        /// <field>
        /// Called after the Created1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Created1"); }],
        /// <field>
        /// Called after the ModifiedBy1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("ModifiedBy1"); }],
        /// <field>
        /// Called after the Modified1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Modified1"); }],
        /// <field>
        /// Called after the Group2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Group2"); }],
        /// <field>
        /// Called after the Environments content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environments_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Environments"); }],
        /// <field>
        /// Called after the EnvironmentsTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EnvironmentsTemplate_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("EnvironmentsTemplate"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Name"); }],
        /// <field>
        /// Called after the Organization2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Organization2"); }],
        /// <field>
        /// Called after the CreatedBy2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("CreatedBy2"); }],
        /// <field>
        /// Called after the Created2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Created2"); }],
        /// <field>
        /// Called after the ModifiedBy2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("ModifiedBy2"); }],
        /// <field>
        /// Called after the Modified2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Modified2"); }],
        /// <field>
        /// Called after the Group3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Group3"); }],
        /// <field>
        /// Called after the Areas content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Areas_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Areas"); }],
        /// <field>
        /// Called after the AreasTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AreasTemplate_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("AreasTemplate"); }],
        /// <field>
        /// Called after the Name3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Name3"); }],
        /// <field>
        /// Called after the Organization4 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization4_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Organization4"); }],
        /// <field>
        /// Called after the CreatedBy3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("CreatedBy3"); }],
        /// <field>
        /// Called after the Created3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Created3"); }],
        /// <field>
        /// Called after the ModifiedBy3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("ModifiedBy3"); }],
        /// <field>
        /// Called after the Modified3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrganization().findContentItem("Modified3"); }]
    });

    lightSwitchApplication.BrowseTickets.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseTickets
        },
        TicketList: {
            _$class: msls.ContentItem,
            _$name: "TicketList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: lightSwitchApplication.BrowseTickets
        },
        TicketNumber1: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber1",
            _$parentName: "TicketList",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: Number
        },
        Tickets: {
            _$class: msls.ContentItem,
            _$name: "Tickets",
            _$parentName: "TicketList",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseTickets,
                _$entry: {
                    elementType: lightSwitchApplication.Ticket
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "Tickets",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketType: {
            _$class: msls.ContentItem,
            _$name: "TicketType",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.TicketType
        },
        TicketNumberPrefix: {
            _$class: msls.ContentItem,
            _$name: "TicketNumberPrefix",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        TicketNumber: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        DateCreated: {
            _$class: msls.ContentItem,
            _$name: "DateCreated",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        WorklistItem: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.WorklistItem
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseTickets
        },
        Group: {
            _$class: msls.ContentItem,
            _$name: "Group",
            _$parentName: "Popups",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: lightSwitchApplication.BrowseTickets
        },
        OrgSelection1: {
            _$class: msls.ContentItem,
            _$name: "OrgSelection1",
            _$parentName: "Group",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: lightSwitchApplication.Organization
        },
        Organization1: {
            _$class: msls.ContentItem,
            _$name: "Organization1",
            _$parentName: "OrgSelection1",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        WorklistItemSel: {
            _$class: msls.ContentItem,
            _$name: "WorklistItemSel",
            _$parentName: "Group",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: lightSwitchApplication.WorklistItem
        },
        WorklistItem2: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem2",
            _$parentName: "WorklistItemSel",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        TickTypSel: {
            _$class: msls.ContentItem,
            _$name: "TickTypSel",
            _$parentName: "Group",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.BrowseTickets,
            value: lightSwitchApplication.TicketType
        },
        TicketType2: {
            _$class: msls.ContentItem,
            _$name: "TicketType2",
            _$parentName: "TickTypSel",
            screen: lightSwitchApplication.BrowseTickets,
            data: lightSwitchApplication.TicketType,
            value: lightSwitchApplication.TicketType
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseTickets, {
        /// <field>
        /// Called when a new BrowseTickets screen is created.
        /// <br/>created(msls.application.BrowseTickets screen)
        /// </field>
        created: [lightSwitchApplication.BrowseTickets],
        /// <field>
        /// Called before changes on an active BrowseTickets screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseTickets screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseTickets],
        /// <field>
        /// Called after the TicketList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketList_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TicketList"); }],
        /// <field>
        /// Called after the TicketNumber1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber1_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TicketNumber1"); }],
        /// <field>
        /// Called after the Tickets content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Tickets_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("Tickets"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("rows"); }],
        /// <field>
        /// Called after the TicketType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TicketType"); }],
        /// <field>
        /// Called after the TicketNumberPrefix content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumberPrefix_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TicketNumberPrefix"); }],
        /// <field>
        /// Called after the TicketNumber content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TicketNumber"); }],
        /// <field>
        /// Called after the DateCreated content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("DateCreated"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("Description"); }],
        /// <field>
        /// Called after the WorklistItem content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("WorklistItem"); }],
        /// <field>
        /// Called after the Group content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("Group"); }],
        /// <field>
        /// Called after the OrgSelection1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        OrgSelection1_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("OrgSelection1"); }],
        /// <field>
        /// Called after the Organization1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization1_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("Organization1"); }],
        /// <field>
        /// Called after the WorklistItemSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItemSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("WorklistItemSel"); }],
        /// <field>
        /// Called after the WorklistItem2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem2_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("WorklistItem2"); }],
        /// <field>
        /// Called after the TickTypSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TickTypSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TickTypSel"); }],
        /// <field>
        /// Called after the TicketType2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType2_postRender: [$element, function () { return new lightSwitchApplication.BrowseTickets().findContentItem("TicketType2"); }]
    });

    lightSwitchApplication.AddEditLogType.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditLogType
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.AddEditLogType,
            value: lightSwitchApplication.AddEditLogType
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.AddEditLogType,
            value: lightSwitchApplication.LogType
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.LogType,
            value: lightSwitchApplication.LogType
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.LogType,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.LogType,
            value: lightSwitchApplication.LogType
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditLogType
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditLogType, {
        /// <field>
        /// Called when a new AddEditLogType screen is created.
        /// <br/>created(msls.application.AddEditLogType screen)
        /// </field>
        created: [lightSwitchApplication.AddEditLogType],
        /// <field>
        /// Called before changes on an active AddEditLogType screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditLogType screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditLogType],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("Name"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("right"); }]
    });

    lightSwitchApplication.AddEditStatus.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditStatus
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditStatus,
            data: lightSwitchApplication.AddEditStatus,
            value: lightSwitchApplication.AddEditStatus
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditStatus,
            data: lightSwitchApplication.AddEditStatus,
            value: lightSwitchApplication.Status
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditStatus,
            data: lightSwitchApplication.Status,
            value: lightSwitchApplication.Status
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditStatus,
            data: lightSwitchApplication.Status,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditStatus,
            data: lightSwitchApplication.Status,
            value: lightSwitchApplication.Status
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditStatus
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditStatus, {
        /// <field>
        /// Called when a new AddEditStatus screen is created.
        /// <br/>created(msls.application.AddEditStatus screen)
        /// </field>
        created: [lightSwitchApplication.AddEditStatus],
        /// <field>
        /// Called before changes on an active AddEditStatus screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditStatus screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditStatus],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatus().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatus().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatus().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatus().findContentItem("Name"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatus().findContentItem("right"); }]
    });

    lightSwitchApplication.AddEditTicketType.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditTicketType
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.AddEditTicketType,
            value: lightSwitchApplication.AddEditTicketType
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.AddEditTicketType,
            value: lightSwitchApplication.TicketType
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: lightSwitchApplication.TicketType
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: lightSwitchApplication.TicketType
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditTicketType
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditTicketType, {
        /// <field>
        /// Called when a new AddEditTicketType screen is created.
        /// <br/>created(msls.application.AddEditTicketType screen)
        /// </field>
        created: [lightSwitchApplication.AddEditTicketType],
        /// <field>
        /// Called before changes on an active AddEditTicketType screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditTicketType screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditTicketType],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("Name"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("right"); }]
    });

    lightSwitchApplication.BrowseWorklistItems.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseWorklistItems
        },
        WorklistItemList: {
            _$class: msls.ContentItem,
            _$name: "WorklistItemList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        Group: {
            _$class: msls.ContentItem,
            _$name: "Group",
            _$parentName: "WorklistItemList",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        WorklistItems: {
            _$class: msls.ContentItem,
            _$name: "WorklistItems",
            _$parentName: "Group",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseWorklistItems,
                _$entry: {
                    elementType: lightSwitchApplication.WorklistItem
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "WorklistItems",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Person
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        Status: {
            _$class: msls.ContentItem,
            _$name: "Status",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Status
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Area
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseWorklistItems
        },
        FilterPopup: {
            _$class: msls.ContentItem,
            _$name: "FilterPopup",
            _$parentName: "Popups",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        PersonSel: {
            _$class: msls.ContentItem,
            _$name: "PersonSel",
            _$parentName: "FilterPopup",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Person
        },
        Person4: {
            _$class: msls.ContentItem,
            _$name: "Person4",
            _$parentName: "PersonSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        OrgSel: {
            _$class: msls.ContentItem,
            _$name: "OrgSel",
            _$parentName: "FilterPopup",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Organization
        },
        OrgSelTemplate: {
            _$class: msls.ContentItem,
            _$name: "OrgSelTemplate",
            _$parentName: "OrgSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        EnvSel: {
            _$class: msls.ContentItem,
            _$name: "EnvSel",
            _$parentName: "FilterPopup",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Environment
        },
        Environment2: {
            _$class: msls.ContentItem,
            _$name: "Environment2",
            _$parentName: "EnvSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        StatusSel: {
            _$class: msls.ContentItem,
            _$name: "StatusSel",
            _$parentName: "FilterPopup",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Status
        },
        Status2: {
            _$class: msls.ContentItem,
            _$name: "Status2",
            _$parentName: "StatusSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Status,
            value: lightSwitchApplication.Status
        },
        AreaSel: {
            _$class: msls.ContentItem,
            _$name: "AreaSel",
            _$parentName: "FilterPopup",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Area
        },
        Area2: {
            _$class: msls.ContentItem,
            _$name: "Area2",
            _$parentName: "AreaSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseWorklistItems, {
        /// <field>
        /// Called when a new BrowseWorklistItems screen is created.
        /// <br/>created(msls.application.BrowseWorklistItems screen)
        /// </field>
        created: [lightSwitchApplication.BrowseWorklistItems],
        /// <field>
        /// Called before changes on an active BrowseWorklistItems screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseWorklistItems screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseWorklistItems],
        /// <field>
        /// Called after the WorklistItemList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItemList_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("WorklistItemList"); }],
        /// <field>
        /// Called after the Group content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Group"); }],
        /// <field>
        /// Called after the WorklistItems content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItems_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("WorklistItems"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("rows"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Name"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Description"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Person"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Environment"); }],
        /// <field>
        /// Called after the Status content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Status_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Status"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Area"); }],
        /// <field>
        /// Called after the FilterPopup content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        FilterPopup_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("FilterPopup"); }],
        /// <field>
        /// Called after the PersonSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        PersonSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("PersonSel"); }],
        /// <field>
        /// Called after the Person4 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person4_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Person4"); }],
        /// <field>
        /// Called after the OrgSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        OrgSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("OrgSel"); }],
        /// <field>
        /// Called after the OrgSelTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        OrgSelTemplate_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("OrgSelTemplate"); }],
        /// <field>
        /// Called after the EnvSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EnvSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("EnvSel"); }],
        /// <field>
        /// Called after the Environment2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment2_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Environment2"); }],
        /// <field>
        /// Called after the StatusSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("StatusSel"); }],
        /// <field>
        /// Called after the Status2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Status2_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Status2"); }],
        /// <field>
        /// Called after the AreaSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AreaSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("AreaSel"); }],
        /// <field>
        /// Called after the Area2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area2_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Area2"); }]
    });

    lightSwitchApplication.ViewWorklistItem.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewWorklistItem
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.ViewWorklistItem,
            value: lightSwitchApplication.ViewWorklistItem
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.ViewWorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        Status: {
            _$class: msls.ContentItem,
            _$name: "Status",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Status
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Area
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Person
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        ModifiedBy: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Modified: {
            _$class: msls.ContentItem,
            _$name: "Modified",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Tickets1: {
            _$class: msls.ContentItem,
            _$name: "Tickets1",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.Ticket
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "Tickets1",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketType: {
            _$class: msls.ContentItem,
            _$name: "TicketType",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.TicketType
        },
        TicketNumberPrefix: {
            _$class: msls.ContentItem,
            _$name: "TicketNumberPrefix",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        TicketNumber: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        DateCreated: {
            _$class: msls.ContentItem,
            _$name: "DateCreated",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        Description1: {
            _$class: msls.ContentItem,
            _$name: "Description1",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        CreatedBy2: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy2",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        Created2: {
            _$class: msls.ContentItem,
            _$name: "Created2",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        LogEntries1: {
            _$class: msls.ContentItem,
            _$name: "LogEntries1",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.LogEntry
                }
            }
        },
        rows1: {
            _$class: msls.ContentItem,
            _$name: "rows1",
            _$parentName: "LogEntries1",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogEntry
        },
        Entry: {
            _$class: msls.ContentItem,
            _$name: "Entry",
            _$parentName: "rows1",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        Created1: {
            _$class: msls.ContentItem,
            _$name: "Created1",
            _$parentName: "rows1",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: Date
        },
        CreatedBy1: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy1",
            _$parentName: "rows1",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewWorklistItem
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewWorklistItem, {
        /// <field>
        /// Called when a new ViewWorklistItem screen is created.
        /// <br/>created(msls.application.ViewWorklistItem screen)
        /// </field>
        created: [lightSwitchApplication.ViewWorklistItem],
        /// <field>
        /// Called before changes on an active ViewWorklistItem screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewWorklistItem screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewWorklistItem],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Name"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Environment"); }],
        /// <field>
        /// Called after the Status content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Status_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Status"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Area"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Person"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Created"); }],
        /// <field>
        /// Called after the ModifiedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("ModifiedBy"); }],
        /// <field>
        /// Called after the Modified content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Modified"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("right"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Description"); }],
        /// <field>
        /// Called after the Tickets1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Tickets1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Tickets1"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("rows"); }],
        /// <field>
        /// Called after the TicketType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("TicketType"); }],
        /// <field>
        /// Called after the TicketNumberPrefix content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumberPrefix_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("TicketNumberPrefix"); }],
        /// <field>
        /// Called after the TicketNumber content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("TicketNumber"); }],
        /// <field>
        /// Called after the DateCreated content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("DateCreated"); }],
        /// <field>
        /// Called after the Description1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Description1"); }],
        /// <field>
        /// Called after the CreatedBy2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy2_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("CreatedBy2"); }],
        /// <field>
        /// Called after the Created2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created2_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Created2"); }],
        /// <field>
        /// Called after the LogEntries1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntries1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("LogEntries1"); }],
        /// <field>
        /// Called after the rows1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("rows1"); }],
        /// <field>
        /// Called after the Entry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Entry_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Entry"); }],
        /// <field>
        /// Called after the Created1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Created1"); }],
        /// <field>
        /// Called after the CreatedBy1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("CreatedBy1"); }]
    });

    lightSwitchApplication.NewWorklistItem.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.NewWorklistItem
        },
        Step1: {
            _$class: msls.ContentItem,
            _$name: "Step1",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Step1",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "left",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Organization
        },
        RowTemplate4: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate4",
            _$parentName: "Organization",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "left",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Step2: {
            _$class: msls.ContentItem,
            _$name: "Step2",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "right",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Area
        },
        RowTemplate2: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate2",
            _$parentName: "Area",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        Status: {
            _$class: msls.ContentItem,
            _$name: "Status",
            _$parentName: "right",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Status
        },
        RowTemplate1: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate1",
            _$parentName: "Status",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Status,
            value: lightSwitchApplication.Status
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "right",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Environment
        },
        RowTemplate: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate",
            _$parentName: "Environment",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "right",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Person
        },
        RowTemplate3: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate3",
            _$parentName: "Person",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        StartDate: {
            _$class: msls.ContentItem,
            _$name: "StartDate",
            _$parentName: "right",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: Date
        },
        EndDate: {
            _$class: msls.ContentItem,
            _$name: "EndDate",
            _$parentName: "right",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: Date
        },
        Tickets1: {
            _$class: msls.ContentItem,
            _$name: "Tickets1",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.NewWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.Ticket
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "Tickets1",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketNumber: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber",
            _$parentName: "rows",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        TicketNumberPrefix: {
            _$class: msls.ContentItem,
            _$name: "TicketNumberPrefix",
            _$parentName: "rows",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        DateCreated: {
            _$class: msls.ContentItem,
            _$name: "DateCreated",
            _$parentName: "rows",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        LastStep: {
            _$class: msls.ContentItem,
            _$name: "LastStep",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        LogEntries1: {
            _$class: msls.ContentItem,
            _$name: "LogEntries1",
            _$parentName: "LastStep",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.NewWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.LogEntry
                }
            }
        },
        rows1: {
            _$class: msls.ContentItem,
            _$name: "rows1",
            _$parentName: "LogEntries1",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogEntry
        },
        Entry: {
            _$class: msls.ContentItem,
            _$name: "Entry",
            _$parentName: "rows1",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        LogType: {
            _$class: msls.ContentItem,
            _$name: "LogType",
            _$parentName: "rows1",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogType
        },
        Organization1: {
            _$class: msls.ContentItem,
            _$name: "Organization1",
            _$parentName: "rows1",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.Organization
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.NewWorklistItem
        }
    };

    msls._addEntryPoints(lightSwitchApplication.NewWorklistItem, {
        /// <field>
        /// Called when a new NewWorklistItem screen is created.
        /// <br/>created(msls.application.NewWorklistItem screen)
        /// </field>
        created: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called before changes on an active NewWorklistItem screen are applied.
        /// <br/>beforeApplyChanges(msls.application.NewWorklistItem screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to determine if the ShowStep2 method can be executed.
        /// <br/>canExecute(msls.application.NewWorklistItem screen)
        /// </field>
        ShowStep2_canExecute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to execute the ShowStep2 method.
        /// <br/>execute(msls.application.NewWorklistItem screen)
        /// </field>
        ShowStep2_execute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to determine if the Finish method can be executed.
        /// <br/>canExecute(msls.application.NewWorklistItem screen)
        /// </field>
        Finish_canExecute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to execute the Finish method.
        /// <br/>execute(msls.application.NewWorklistItem screen)
        /// </field>
        Finish_execute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called after the Step1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Step1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Step1"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("left"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Organization"); }],
        /// <field>
        /// Called after the RowTemplate4 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate4_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("RowTemplate4"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Name"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Description"); }],
        /// <field>
        /// Called after the Step2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Step2_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Step2"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("right"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Area"); }],
        /// <field>
        /// Called after the RowTemplate2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate2_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("RowTemplate2"); }],
        /// <field>
        /// Called after the Status content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Status_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Status"); }],
        /// <field>
        /// Called after the RowTemplate1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("RowTemplate1"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Environment"); }],
        /// <field>
        /// Called after the RowTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("RowTemplate"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Person"); }],
        /// <field>
        /// Called after the RowTemplate3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate3_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("RowTemplate3"); }],
        /// <field>
        /// Called after the StartDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StartDate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("StartDate"); }],
        /// <field>
        /// Called after the EndDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EndDate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("EndDate"); }],
        /// <field>
        /// Called after the Tickets1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Tickets1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Tickets1"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("rows"); }],
        /// <field>
        /// Called after the TicketNumber content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("TicketNumber"); }],
        /// <field>
        /// Called after the TicketNumberPrefix content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumberPrefix_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("TicketNumberPrefix"); }],
        /// <field>
        /// Called after the DateCreated content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("DateCreated"); }],
        /// <field>
        /// Called after the LastStep content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LastStep_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("LastStep"); }],
        /// <field>
        /// Called after the LogEntries1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntries1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("LogEntries1"); }],
        /// <field>
        /// Called after the rows1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("rows1"); }],
        /// <field>
        /// Called after the Entry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Entry_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Entry"); }],
        /// <field>
        /// Called after the LogType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogType_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("LogType"); }],
        /// <field>
        /// Called after the Organization1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Organization1"); }]
    });

}(msls.application));