﻿/// <reference path="data.js" />

(function (lightSwitchApplication) {

    var $Screen = msls.Screen,
        $defineScreen = msls._defineScreen,
        $DataServiceQuery = msls.DataServiceQuery,
        $toODataString = msls._toODataString,
        $defineShowScreen = msls._defineShowScreen;

    function AddEditArea(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditArea screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Area" type="msls.application.Area">
        /// Gets or sets the area for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditArea.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditArea", parameters);
    }

    function AddEditEnvironment(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditEnvironment screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Environment" type="msls.application.Environment">
        /// Gets or sets the environment for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditEnvironment.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditEnvironment", parameters);
    }

    function AddEditOrganization(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditOrganization screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditOrganization.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditOrganization", parameters);
    }

    function AddEditPerson(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditPerson screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Person" type="msls.application.Person">
        /// Gets or sets the person for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditPerson.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditPerson", parameters);
    }

    function BrowseOrganizations(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseOrganizations screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Organizations" type="msls.VisualCollection" elementType="msls.application.Organization">
        /// Gets the organizations for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseOrganizations.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseOrganizations", parameters);
    }

    function ViewOrganization(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewOrganization screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this screen.
        /// </field>
        /// <field name="WorklistItems" type="msls.VisualCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this screen.
        /// </field>
        /// <field name="Environments" type="msls.VisualCollection" elementType="msls.application.Environment">
        /// Gets the environments for this screen.
        /// </field>
        /// <field name="Areas" type="msls.VisualCollection" elementType="msls.application.Area">
        /// Gets the areas for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewOrganization.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewOrganization", parameters);
    }

    function BrowseTickets(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseTickets screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Tickets" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this screen.
        /// </field>
        /// <field name="OrgSelection" type="msls.application.Organization">
        /// Gets or sets the orgSelection for this screen.
        /// </field>
        /// <field name="TickTypSel" type="msls.application.TicketType">
        /// Gets or sets the tickTypSel for this screen.
        /// </field>
        /// <field name="WorklistItemSel" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItemSel for this screen.
        /// </field>
        /// <field name="WorklistItemsByOrgID" type="msls.VisualCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItemsByOrgID for this screen.
        /// </field>
        /// <field name="TicketNumber" type="Number">
        /// Gets or sets the ticketNumber for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseTickets.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseTickets", parameters);
    }

    function AddEditLogType(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditLogType screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="LogType" type="msls.application.LogType">
        /// Gets or sets the logType for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditLogType.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditLogType", parameters);
    }

    function AddEditStatus(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditStatus screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Status" type="msls.application.Status">
        /// Gets or sets the status for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditStatus.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditStatus", parameters);
    }

    function AddEditTicketType(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditTicketType screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="TicketType" type="msls.application.TicketType">
        /// Gets or sets the ticketType for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditTicketType.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditTicketType", parameters);
    }

    function BrowseWorklistItems(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseWorklistItems screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItems" type="msls.VisualCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this screen.
        /// </field>
        /// <field name="OrgSel" type="msls.application.Organization">
        /// Gets or sets the orgSel for this screen.
        /// </field>
        /// <field name="EnvSel" type="msls.application.Environment">
        /// Gets or sets the envSel for this screen.
        /// </field>
        /// <field name="StatusSel" type="msls.application.Status">
        /// Gets or sets the statusSel for this screen.
        /// </field>
        /// <field name="PersonSel" type="msls.application.Person">
        /// Gets or sets the personSel for this screen.
        /// </field>
        /// <field name="AreasByOrgID" type="msls.VisualCollection" elementType="msls.application.Area">
        /// Gets the areasByOrgID for this screen.
        /// </field>
        /// <field name="AreaSel" type="msls.application.Area">
        /// Gets or sets the areaSel for this screen.
        /// </field>
        /// <field name="EnvsByOrgID" type="msls.VisualCollection" elementType="msls.application.Environment">
        /// Gets the envsByOrgID for this screen.
        /// </field>
        /// <field name="TicketByWorklistID" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the ticketByWorklistID for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseWorklistItems.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseWorklistItems", parameters);
    }

    function ViewWorklistItem(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewWorklistItem screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this screen.
        /// </field>
        /// <field name="Tickets" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this screen.
        /// </field>
        /// <field name="LogEntries" type="msls.VisualCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewWorklistItem.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewWorklistItem", parameters);
    }

    function NewWorklistItem(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the NewWorklistItem screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this screen.
        /// </field>
        /// <field name="Tickets" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this screen.
        /// </field>
        /// <field name="LogEntries" type="msls.VisualCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this screen.
        /// </field>
        /// <field name="details" type="msls.application.NewWorklistItem.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "NewWorklistItem", parameters);
    }

    msls._addToNamespace("msls.application", {

        AddEditArea: $defineScreen(AddEditArea, [
            { name: "Area", kind: "local", type: lightSwitchApplication.Area }
        ], [
        ]),

        AddEditEnvironment: $defineScreen(AddEditEnvironment, [
            { name: "Environment", kind: "local", type: lightSwitchApplication.Environment }
        ], [
        ]),

        AddEditOrganization: $defineScreen(AddEditOrganization, [
            { name: "Organization", kind: "local", type: lightSwitchApplication.Organization }
        ], [
        ]),

        AddEditPerson: $defineScreen(AddEditPerson, [
            { name: "Person", kind: "local", type: lightSwitchApplication.Person }
        ], [
        ]),

        BrowseOrganizations: $defineScreen(BrowseOrganizations, [
            {
                name: "Organizations", kind: "collection", elementType: lightSwitchApplication.Organization,
                createQuery: function () {
                    return this.dataWorkspace.ApplicationData.Organizations;
                }
            }
        ], [
            { name: "DeleteOrg" }
        ]),

        ViewOrganization: $defineScreen(ViewOrganization, [
            { name: "Organization", kind: "local", type: lightSwitchApplication.Organization },
            {
                name: "WorklistItems", kind: "collection", elementType: lightSwitchApplication.WorklistItem,
                createQuery: function (OrgName) {
                    return this.dataWorkspace.ApplicationData.WorklistItems.filter("" + ((OrgName === undefined || OrgName === null) ? "true" : "substringof(" + $toODataString(OrgName, "String?") + ", Organization/Name)") + "").expand("Environment").expand("Status");
                }
            },
            {
                name: "Environments", kind: "collection", elementType: lightSwitchApplication.Environment,
                getNavigationProperty: function () {
                    if (this.owner.Organization) {
                        return this.owner.Organization.details.properties.Environments;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("Organization");
                }
            },
            {
                name: "Areas", kind: "collection", elementType: lightSwitchApplication.Area,
                getNavigationProperty: function () {
                    if (this.owner.Organization) {
                        return this.owner.Organization.details.properties.Areas;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("Organization");
                }
            }
        ], [
            { name: "DeleteArea" },
            { name: "DeleteEnvironment" },
            { name: "DeletePerson" }
        ]),

        BrowseTickets: $defineScreen(BrowseTickets, [
            {
                name: "Tickets", kind: "collection", elementType: lightSwitchApplication.Ticket,
                createQuery: function (NameOrg, IdTickType, IdWorkItem, TicketNumber) {
                    return this.dataWorkspace.ApplicationData.Tickets.filter("((" + ((NameOrg === undefined || NameOrg === null) ? "true" : "substringof(" + $toODataString(NameOrg, "String?") + ", WorklistItem/Organization/Name)") + " and " + ((IdTickType === undefined || IdTickType === null) ? "true" : "(TicketType/Id eq " + $toODataString(IdTickType, "Int32?") + ")") + ") and " + ((IdWorkItem === undefined || IdWorkItem === null) ? "true" : "(WorklistItem/Id eq " + $toODataString(IdWorkItem, "Int32?") + ")") + ") and " + ((TicketNumber === undefined || TicketNumber === null) ? "true" : "(TicketNumber eq " + $toODataString(TicketNumber, "Int32?") + ")") + "").expand("TicketType").expand("WorklistItem").expand("WorklistItem/Environment").expand("WorklistItem/Status");
                }
            },
            { name: "OrgSelection", kind: "local", type: lightSwitchApplication.Organization },
            { name: "TickTypSel", kind: "local", type: lightSwitchApplication.TicketType },
            { name: "WorklistItemSel", kind: "local", type: lightSwitchApplication.WorklistItem },
            {
                name: "WorklistItemsByOrgID", kind: "collection", elementType: lightSwitchApplication.WorklistItem,
                createQuery: function (Id) {
                    return this.dataWorkspace.ApplicationData.WorklistItemsByOrgID(Id).filter("" + ((Id === undefined || Id === null) ? "true" : "(Organization/Id eq " + $toODataString(Id, "Int32?") + ")") + "");
                }
            },
            { name: "TicketNumber", kind: "local", type: Number }
        ], [
        ]),

        AddEditLogType: $defineScreen(AddEditLogType, [
            { name: "LogType", kind: "local", type: lightSwitchApplication.LogType }
        ], [
        ]),

        AddEditStatus: $defineScreen(AddEditStatus, [
            { name: "Status", kind: "local", type: lightSwitchApplication.Status }
        ], [
        ]),

        AddEditTicketType: $defineScreen(AddEditTicketType, [
            { name: "TicketType", kind: "local", type: lightSwitchApplication.TicketType }
        ], [
        ]),

        BrowseWorklistItems: $defineScreen(BrowseWorklistItems, [
            {
                name: "WorklistItems", kind: "collection", elementType: lightSwitchApplication.WorklistItem,
                createQuery: function (Name, EnvName, StatusName, PersonId, AreaName) {
                    return this.dataWorkspace.ApplicationData.WorklistItems.filter("(((" + ((Name === undefined || Name === null) ? "true" : "substringof(" + $toODataString(Name, "String?") + ", Organization/Name)") + " and " + ((EnvName === undefined || EnvName === null) ? "true" : "substringof(" + $toODataString(EnvName, "String?") + ", Environment/Name)") + ") and " + ((StatusName === undefined || StatusName === null) ? "true" : "substringof(" + $toODataString(StatusName, "String?") + ", Status/Name)") + ") and " + ((PersonId === undefined || PersonId === null) ? "true" : "(Person/Id eq " + $toODataString(PersonId, "Int32?") + ")") + ") and " + ((AreaName === undefined || AreaName === null) ? "true" : "substringof(" + $toODataString(AreaName, "String?") + ", Area/Name)") + "").expand("Person").expand("Environment").expand("Status").expand("Area");
                }
            },
            { name: "OrgSel", kind: "local", type: lightSwitchApplication.Organization },
            { name: "EnvSel", kind: "local", type: lightSwitchApplication.Environment },
            { name: "StatusSel", kind: "local", type: lightSwitchApplication.Status },
            { name: "PersonSel", kind: "local", type: lightSwitchApplication.Person },
            {
                name: "AreasByOrgID", kind: "collection", elementType: lightSwitchApplication.Area,
                createQuery: function (Id) {
                    return this.dataWorkspace.ApplicationData.AreasByOrgID(Id);
                }
            },
            { name: "AreaSel", kind: "local", type: lightSwitchApplication.Area },
            {
                name: "EnvsByOrgID", kind: "collection", elementType: lightSwitchApplication.Environment,
                createQuery: function (Id) {
                    return this.dataWorkspace.ApplicationData.EnvsByOrgID(Id);
                }
            },
            {
                name: "TicketByWorklistID", kind: "collection", elementType: lightSwitchApplication.Ticket,
                createQuery: function (Id) {
                    return this.dataWorkspace.ApplicationData.TicketByWorklistID(Id);
                }
            }
        ], [
        ]),

        ViewWorklistItem: $defineScreen(ViewWorklistItem, [
            { name: "WorklistItem", kind: "local", type: lightSwitchApplication.WorklistItem },
            {
                name: "Tickets", kind: "collection", elementType: lightSwitchApplication.Ticket,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.Tickets;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("TicketType");
                }
            },
            {
                name: "LogEntries", kind: "collection", elementType: lightSwitchApplication.LogEntry,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.LogEntries;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            }
        ], [
        ]),

        NewWorklistItem: $defineScreen(NewWorklistItem, [
            { name: "WorklistItem", kind: "local", type: lightSwitchApplication.WorklistItem },
            {
                name: "Tickets", kind: "collection", elementType: lightSwitchApplication.Ticket,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.Tickets;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            },
            {
                name: "LogEntries", kind: "collection", elementType: lightSwitchApplication.LogEntry,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.LogEntries;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("LogType").expand("Organization");
                }
            }
        ], [
            { name: "ShowStep2" },
            { name: "Finish" }
        ]),

        showAddEditArea: $defineShowScreen(function showAddEditArea(Area, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditArea screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditArea", parameters, options);
        }),

        showAddEditEnvironment: $defineShowScreen(function showAddEditEnvironment(Environment, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditEnvironment screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditEnvironment", parameters, options);
        }),

        showAddEditOrganization: $defineShowScreen(function showAddEditOrganization(Organization, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditOrganization screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditOrganization", parameters, options);
        }),

        showAddEditPerson: $defineShowScreen(function showAddEditPerson(Person, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditPerson screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditPerson", parameters, options);
        }),

        showBrowseOrganizations: $defineShowScreen(function showBrowseOrganizations(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseOrganizations screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseOrganizations", parameters, options);
        }),

        showViewOrganization: $defineShowScreen(function showViewOrganization(Organization, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewOrganization screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewOrganization", parameters, options);
        }),

        showBrowseTickets: $defineShowScreen(function showBrowseTickets(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseTickets screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseTickets", parameters, options);
        }),

        showAddEditLogType: $defineShowScreen(function showAddEditLogType(LogType, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditLogType screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditLogType", parameters, options);
        }),

        showAddEditStatus: $defineShowScreen(function showAddEditStatus(Status, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditStatus screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditStatus", parameters, options);
        }),

        showAddEditTicketType: $defineShowScreen(function showAddEditTicketType(TicketType, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditTicketType screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditTicketType", parameters, options);
        }),

        showBrowseWorklistItems: $defineShowScreen(function showBrowseWorklistItems(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseWorklistItems screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseWorklistItems", parameters, options);
        }),

        showViewWorklistItem: $defineShowScreen(function showViewWorklistItem(WorklistItem, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewWorklistItem screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewWorklistItem", parameters, options);
        }),

        showNewWorklistItem: $defineShowScreen(function showNewWorklistItem(WorklistItem, options) {
            /// <summary>
            /// Asynchronously navigates forward to the NewWorklistItem screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("NewWorklistItem", parameters, options);
        })

    });

}(msls.application));
