﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.NewWorklistItem.ShowStep2_execute = function (screen) {
    if (screen.WorklistItem.Organization == null || screen.WorklistItem.Organization == undefined) {
        screen.WorklistItem.Organization = null;
    }
    var contentItem = screen.findContentItem("WorklistItem");
    if (contentItem.validationResults.length === 0) {
        screen.showTab("Step2");
        screen.details.displayName = "Step 2";
    }
};

myapp.NewWorklistItem.Finish_execute = function (screen) {
    myapp.commitChanges();
};