﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.ViewOrganization.Details_postRender = function (element, contentItem) {
    var name = contentItem.screen.Organization.details.getModel()[':@SummaryProperty'].property.name;
    contentItem.dataBind("screen.Organization." + name, function (value) {
        contentItem.screen.details.displayName = value;
    });
}


myapp.ViewOrganization.created = function (screen) {
    var name = screen.Organization.Name;
    screen.details.displayName = name;
};

myapp.ViewOrganization.DeleteArea_execute = function (screen) {
    screen.getAreas().then(function (areas) {
        areas.deleteSelected();
    });

};

myapp.ViewOrganization.DeleteEnvironment_execute = function (screen) {
    screen.getEnvironments().then(function (environs) {
        environs.deleteSelected();
    });
};

myapp.ViewOrganization.DeletePerson_execute = function (screen) {
    screen.getPeople().then(function (people) {
        people.deleteSelected();
    });
};