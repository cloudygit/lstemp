﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.LogType.created = function (entity) {
    // Write code here.

};