﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.TicketType.created = function (entity) {
    // Write code here.

};