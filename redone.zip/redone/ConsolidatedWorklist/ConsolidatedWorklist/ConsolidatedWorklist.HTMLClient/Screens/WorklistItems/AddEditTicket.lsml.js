﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditTicket.DeleteTicket_execute = function (screen) {
    // Write code here.
    msls.showMessageBox("Are you sure you want to delete this ticket?", {
        title: "Confirm Delete",
        buttons: msls.MessageBoxButtons.okCancel
    }).then(function (result) {
        if (result === msls.MessageBoxResult.ok) {
            screen.Ticket.deleteEntity();
            // screen.getTickets().then(function (ticket) {
        
            //   ticket.deleteSelected();
        }
            return myapp.commitChanges().then(null, function fail(e) {
                myapp.cancelChanges();
                throw e;
            });
        }
    );
};


/*
myapp.AddEditTicket.beforeApplyChanges = function (screen) {
    // Write code here.
    if (screen.Ticket.TicketType == null) {
        screen.Ticket.TicketType = null;
        var tickType = screen.findContentItem("TicketType");
        tickType.validationResults = [
            new msls.ValidationResult(screen.Ticket.details.properties.TicketType, "This field is required.")
        ];
    } else {
        tickType.validationResults = [];
    }
};
myapp.AddEditTicket.TicketType_postRender = function (element, contentItem) {
    // Write code here.
    if (contentItem == null) {

    }
};
*/