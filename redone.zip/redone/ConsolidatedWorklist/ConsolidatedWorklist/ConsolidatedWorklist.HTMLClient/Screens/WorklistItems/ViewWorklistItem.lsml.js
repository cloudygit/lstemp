﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.ViewWorklistItem.Details_postRender = function (element, contentItem) {
    // Write code here.
    var name = contentItem.screen.WorklistItem.details.getModel()[':@SummaryProperty'].property.name;
    contentItem.dataBind("screen.WorklistItem." + name, function (value) {
        contentItem.screen.details.displayName = value;
    });
}


myapp.ViewWorklistItem.ShowLogEntry_execute = function (screen) {
    // Write code here.
    //addeditlogentry
    myapp.showAddEditLogEntry(null, {
        beforeShown: function (AddEditScreen) {
            var newLogItem = new myapp.LogEntry();
            //newLogItem.LogType = "UserComment";
            newLogItem.WorklistItem = screen.WorklistItem;
            AddEditScreen.LogEntry = newLogItem;
            
        } /*,
        afterClosed: function (addEditScreen, navigationAction) {
            if (navigationAction === msls.NavigateBackAction.commit) {
                var newItem = addEditScreen.WorklistItem;
                myapp.showViewWorklistItem(newItem);
            }
        }*/
        
    })

};
