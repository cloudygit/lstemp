﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.AddEditWorklistItem.DeleteThisWorklist_execute = function (screen) {
    msls.showMessageBox("Are you sure you want to delete this worklist item and its associated tickets and data?", {
        title: "Confirm Delete",
        buttons: msls.MessageBoxButtons.okCancel
    }).then(function (result) {
        if (result === msls.MessageBoxResult.ok) {
            screen.getWorklistItems().then(function (worklistitem) {
                worklistitem.deleteSelected();
            });
            return myapp.commitChanges().then(null, function fail(e) {
                myapp.cancelChanges();
                throw e;
            });
        }
    });
};


myapp.AddEditWorklistItem.Tickets1_postRender = function (element, contentItem) {
    // Write code here.

};