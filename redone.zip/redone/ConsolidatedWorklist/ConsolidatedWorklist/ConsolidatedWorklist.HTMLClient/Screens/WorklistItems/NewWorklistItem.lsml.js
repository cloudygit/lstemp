﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.NewWorklistItem.ShowStep2_execute = function (screen) {
    var org;
    var name;
    var desc;

    org = screen.findContentItem("WorklistItem_Organization");

    if (screen.WorklistItem.Organization == null) {
        screen.WorklistItem.Organization = null;
        org.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Organization, "This field is required.")
        ];
    } else {
        org.validationResults = [];
    }

    name = screen.findContentItem("WorklistItem_Name");
    if (screen.WorklistItem.Name == null) {
        screen.WorklistItem.Name = null;
    } else {
        name.validationResults = [];
    }

    desc = screen.findContentItem("WorklistItem_Description");

    if (name.validationResults.length === 0 && org.validationResults.length === 0 && desc.validationResults.length === 0) {
        screen.showTab("Step2");
        screen.details.displayName = "Step 2";
    }

};

myapp.NewWorklistItem.ShowStep3_execute = function (screen) {
    var hasError = false;
    var contentItem;

    contentItem = screen.findContentItem("WorklistItem_Area");
    if (screen.WorklistItem.Area == null) {
        screen.WorklistItem.Area = null;
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Area, "This field is required.")
        ];
        hasError = true;
    } else {
        contentItem.validationResults = [];
    }

    contentItem = screen.findContentItem("WorklistItem_StatusSet");
    if (screen.WorklistItem.StatusSet == null) {
        screen.WorklistItem.StatusSet = null;
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.StatusSet, "This field is required.")
        ];
        hasError = true;
    } else {
        contentItem.validationResults = [];
    }

    contentItem = screen.findContentItem("WorklistItem_Environment");
    if (screen.WorklistItem.Environment == null) {
        screen.WorklistItem.Environment = null;
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Environment, "This field is required.")
        ];
        hasError = true;
    } else {
        contentItem.validationResults = [];
    }

    contentItem = screen.findContentItem("WorklistItem_Person");
    if (screen.WorklistItem.Person == null) {
        screen.WorklistItem.Person = null;
        contentItem.validationResults = [
            new msls.ValidationResult(screen.WorklistItem.details.properties.Person, "This field is required.")
        ];
        hasError = true;
    } else {
        contentItem.validationResults = [];
    }

    if (!hasError) {
        screen.showTab("Step3");
        screen.details.displayName = "Step 3";
    }
};

myapp.NewWorklistItem.Finish_execute = function (screen) {

    msls.application.commitChanges().then(null, function fail(e) {
        msls.showMessageBox("Worklist Item already exists with this name").then(function () {
            screen.showTab("Group");
        });
       throw e;
    });

};

