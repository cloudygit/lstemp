﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.BrowseWorklistItems.AddAndViewWorklistItem_execute = function (screen) {
    myapp.showNewWorklistItem(null, {
        beforeShown: function (AddEditScreen) {
            var newWorklistItem = new myapp.WorklistItem();
            AddEditScreen.WorklistItem = newWorklistItem;

        },
        afterClosed: function (addEditScreen, navigationAction) {
            if (navigationAction === msls.NavigateBackAction.commit) {
                var newItem = addEditScreen.WorklistItem;
                myapp.showViewWorklistItem(newItem);
            }
        }
    })
};
myapp.BrowseWorklistItems.DeleteSelectedWorklistItem_execute = function (screen) {
    msls.showMessageBox("Are you sure you want to delete this worklist item and its associated tickets and data?", {
        title: "Confirm Delete",
        buttons: msls.MessageBoxButtons.okCancel
    }).then(function (result) {
        if (result === msls.MessageBoxResult.ok) {
            screen.getWorklistItems().then(function (worklistitem) {
                worklistitem.deleteSelected();
            });
            return myapp.commitChanges().then(null, function fail(e) {
                myapp.cancelChanges();
                throw e;
            });
        }
    });
};
