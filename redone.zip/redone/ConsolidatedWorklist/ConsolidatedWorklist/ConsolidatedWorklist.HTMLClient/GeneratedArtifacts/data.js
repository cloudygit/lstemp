﻿/// <reference path="../Scripts/msls.js" />

window.myapp = msls.application;

(function (lightSwitchApplication) {

    var $Entity = msls.Entity,
        $DataService = msls.DataService,
        $DataWorkspace = msls.DataWorkspace,
        $defineEntity = msls._defineEntity,
        $defineDataService = msls._defineDataService,
        $defineDataWorkspace = msls._defineDataWorkspace,
        $DataServiceQuery = msls.DataServiceQuery,
        $toODataString = msls._toODataString;

    function Area(entitySet) {
        /// <summary>
        /// Represents the Area entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this area.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this area.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this area.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this area.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this area.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this area.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this area.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this area.
        /// </field>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this area.
        /// </field>
        /// <field name="WorklistItems" type="msls.EntityCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this area.
        /// </field>
        /// <field name="details" type="msls.application.Area.Details">
        /// Gets the details for this area.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function Environment(entitySet) {
        /// <summary>
        /// Represents the Environment entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this environment.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this environment.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this environment.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this environment.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this environment.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this environment.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this environment.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this environment.
        /// </field>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this environment.
        /// </field>
        /// <field name="WorklistItems" type="msls.EntityCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this environment.
        /// </field>
        /// <field name="details" type="msls.application.Environment.Details">
        /// Gets the details for this environment.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function LogEntry(entitySet) {
        /// <summary>
        /// Represents the LogEntry entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this logEntry.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this logEntry.
        /// </field>
        /// <field name="Entry" type="String">
        /// Gets or sets the entry for this logEntry.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this logEntry.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this logEntry.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this logEntry.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this logEntry.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this logEntry.
        /// </field>
        /// <field name="LogType" type="msls.application.LogType">
        /// Gets or sets the logType for this logEntry.
        /// </field>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this logEntry.
        /// </field>
        /// <field name="details" type="msls.application.LogEntry.Details">
        /// Gets the details for this logEntry.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function LogType(entitySet) {
        /// <summary>
        /// Represents the LogType entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this logType.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this logType.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this logType.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this logType.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this logType.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this logType.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this logType.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this logType.
        /// </field>
        /// <field name="LogEntries" type="msls.EntityCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this logType.
        /// </field>
        /// <field name="details" type="msls.application.LogType.Details">
        /// Gets the details for this logType.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function Organization(entitySet) {
        /// <summary>
        /// Represents the Organization entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this organization.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this organization.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this organization.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this organization.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this organization.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this organization.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this organization.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this organization.
        /// </field>
        /// <field name="Areas" type="msls.EntityCollection" elementType="msls.application.Area">
        /// Gets the areas for this organization.
        /// </field>
        /// <field name="Environments" type="msls.EntityCollection" elementType="msls.application.Environment">
        /// Gets the environments for this organization.
        /// </field>
        /// <field name="StatusSet" type="msls.EntityCollection" elementType="msls.application.StatusSet">
        /// Gets the statusSet for this organization.
        /// </field>
        /// <field name="WorklistItems" type="msls.EntityCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this organization.
        /// </field>
        /// <field name="details" type="msls.application.Organization.Details">
        /// Gets the details for this organization.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function Person(entitySet) {
        /// <summary>
        /// Represents the Person entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this person.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this person.
        /// </field>
        /// <field name="DisplayName" type="String">
        /// Gets or sets the displayName for this person.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this person.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this person.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this person.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this person.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this person.
        /// </field>
        /// <field name="WorklistItems" type="msls.EntityCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this person.
        /// </field>
        /// <field name="details" type="msls.application.Person.Details">
        /// Gets the details for this person.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function StatusSet(entitySet) {
        /// <summary>
        /// Represents the StatusSet entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this statusSet.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this statusSet.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this statusSet.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this statusSet.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this statusSet.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this statusSet.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this statusSet.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this statusSet.
        /// </field>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this statusSet.
        /// </field>
        /// <field name="WorklistItems" type="msls.EntityCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this statusSet.
        /// </field>
        /// <field name="details" type="msls.application.StatusSet.Details">
        /// Gets the details for this statusSet.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function Ticket(entitySet) {
        /// <summary>
        /// Represents the Ticket entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this ticket.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this ticket.
        /// </field>
        /// <field name="TicketNumber" type="Number">
        /// Gets or sets the ticketNumber for this ticket.
        /// </field>
        /// <field name="DateCreated" type="Date">
        /// Gets or sets the dateCreated for this ticket.
        /// </field>
        /// <field name="Description" type="String">
        /// Gets or sets the description for this ticket.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this ticket.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this ticket.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this ticket.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this ticket.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this ticket.
        /// </field>
        /// <field name="TicketType" type="msls.application.TicketType">
        /// Gets or sets the ticketType for this ticket.
        /// </field>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this ticket.
        /// </field>
        /// <field name="details" type="msls.application.Ticket.Details">
        /// Gets the details for this ticket.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function TicketType(entitySet) {
        /// <summary>
        /// Represents the TicketType entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this ticketType.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this ticketType.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this ticketType.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this ticketType.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this ticketType.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this ticketType.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this ticketType.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this ticketType.
        /// </field>
        /// <field name="Tickets" type="msls.EntityCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this ticketType.
        /// </field>
        /// <field name="details" type="msls.application.TicketType.Details">
        /// Gets the details for this ticketType.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function WorklistItem(entitySet) {
        /// <summary>
        /// Represents the WorklistItem entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this worklistItem.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this worklistItem.
        /// </field>
        /// <field name="Name" type="String">
        /// Gets or sets the name for this worklistItem.
        /// </field>
        /// <field name="Description" type="String">
        /// Gets or sets the description for this worklistItem.
        /// </field>
        /// <field name="StartDate" type="Date">
        /// Gets or sets the startDate for this worklistItem.
        /// </field>
        /// <field name="EndDate" type="Date">
        /// Gets or sets the endDate for this worklistItem.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this worklistItem.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this worklistItem.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this worklistItem.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this worklistItem.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this worklistItem.
        /// </field>
        /// <field name="Area" type="msls.application.Area">
        /// Gets or sets the area for this worklistItem.
        /// </field>
        /// <field name="StatusSet" type="msls.application.StatusSet">
        /// Gets or sets the statusSet for this worklistItem.
        /// </field>
        /// <field name="Environment" type="msls.application.Environment">
        /// Gets or sets the environment for this worklistItem.
        /// </field>
        /// <field name="LogEntries" type="msls.EntityCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this worklistItem.
        /// </field>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this worklistItem.
        /// </field>
        /// <field name="Person" type="msls.application.Person">
        /// Gets or sets the person for this worklistItem.
        /// </field>
        /// <field name="Tickets" type="msls.EntityCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this worklistItem.
        /// </field>
        /// <field name="details" type="msls.application.WorklistItem.Details">
        /// Gets the details for this worklistItem.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function CoWoItData(dataWorkspace) {
        /// <summary>
        /// Represents the CoWoItData data service.
        /// </summary>
        /// <param name="dataWorkspace" type="msls.DataWorkspace">
        /// The data workspace that created this data service.
        /// </param>
        /// <field name="Areas" type="msls.EntitySet">
        /// Gets the Areas entity set.
        /// </field>
        /// <field name="Environments" type="msls.EntitySet">
        /// Gets the Environments entity set.
        /// </field>
        /// <field name="LogEntries" type="msls.EntitySet">
        /// Gets the LogEntries entity set.
        /// </field>
        /// <field name="LogTypes" type="msls.EntitySet">
        /// Gets the LogTypes entity set.
        /// </field>
        /// <field name="Organizations" type="msls.EntitySet">
        /// Gets the Organizations entity set.
        /// </field>
        /// <field name="People" type="msls.EntitySet">
        /// Gets the People entity set.
        /// </field>
        /// <field name="StatusSet" type="msls.EntitySet">
        /// Gets the StatusSet entity set.
        /// </field>
        /// <field name="Tickets" type="msls.EntitySet">
        /// Gets the Tickets entity set.
        /// </field>
        /// <field name="TicketTypes" type="msls.EntitySet">
        /// Gets the TicketTypes entity set.
        /// </field>
        /// <field name="WorklistItems" type="msls.EntitySet">
        /// Gets the WorklistItems entity set.
        /// </field>
        /// <field name="details" type="msls.application.CoWoItData.Details">
        /// Gets the details for this data service.
        /// </field>
        $DataService.call(this, dataWorkspace);
    };
    function DataWorkspace() {
        /// <summary>
        /// Represents the data workspace.
        /// </summary>
        /// <field name="CoWoItData" type="msls.application.CoWoItData">
        /// Gets the CoWoItData data service.
        /// </field>
        /// <field name="details" type="msls.application.DataWorkspace.Details">
        /// Gets the details for this data workspace.
        /// </field>
        $DataWorkspace.call(this);
    };

    msls._addToNamespace("msls.application", {

        Area: $defineEntity(Area, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "Organization", kind: "reference", type: Organization },
            { name: "WorklistItems", kind: "collection", elementType: WorklistItem }
        ]),

        Environment: $defineEntity(Environment, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "Organization", kind: "reference", type: Organization },
            { name: "WorklistItems", kind: "collection", elementType: WorklistItem }
        ]),

        LogEntry: $defineEntity(LogEntry, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Entry", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "LogType", kind: "reference", type: LogType },
            { name: "WorklistItem", kind: "reference", type: WorklistItem }
        ]),

        LogType: $defineEntity(LogType, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "LogEntries", kind: "collection", elementType: LogEntry }
        ]),

        Organization: $defineEntity(Organization, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "Areas", kind: "collection", elementType: Area },
            { name: "Environments", kind: "collection", elementType: Environment },
            { name: "StatusSet", kind: "collection", elementType: StatusSet },
            { name: "WorklistItems", kind: "collection", elementType: WorklistItem }
        ]),

        Person: $defineEntity(Person, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "DisplayName", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "WorklistItems", kind: "collection", elementType: WorklistItem }
        ]),

        StatusSet: $defineEntity(StatusSet, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "Organization", kind: "reference", type: Organization },
            { name: "WorklistItems", kind: "collection", elementType: WorklistItem }
        ]),

        Ticket: $defineEntity(Ticket, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "TicketNumber", type: Number },
            { name: "DateCreated", type: Date },
            { name: "Description", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "TicketType", kind: "reference", type: TicketType },
            { name: "WorklistItem", kind: "reference", type: WorklistItem }
        ]),

        TicketType: $defineEntity(TicketType, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "Tickets", kind: "collection", elementType: Ticket }
        ]),

        WorklistItem: $defineEntity(WorklistItem, [
            { name: "Id", type: Number, isReadOnly: true },
            { name: "Name", type: String },
            { name: "Description", type: String },
            { name: "StartDate", type: Date },
            { name: "EndDate", type: Date },
            { name: "CreatedBy", type: String },
            { name: "Created", type: Date },
            { name: "ModifiedBy", type: String },
            { name: "Modified", type: Date },
            { name: "RowVersion", type: Array, isReadOnly: true },
            { name: "Area", kind: "reference", type: Area },
            { name: "StatusSet", kind: "reference", type: StatusSet },
            { name: "Environment", kind: "reference", type: Environment },
            { name: "LogEntries", kind: "collection", elementType: LogEntry },
            { name: "Organization", kind: "reference", type: Organization },
            { name: "Person", kind: "reference", type: Person },
            { name: "Tickets", kind: "collection", elementType: Ticket }
        ]),

        CoWoItData: $defineDataService(CoWoItData, lightSwitchApplication.rootUri + "/CoWoItData.svc", [
            { name: "Areas", elementType: Area },
            { name: "Environments", elementType: Environment },
            { name: "LogEntries", elementType: LogEntry },
            { name: "LogTypes", elementType: LogType },
            { name: "Organizations", elementType: Organization },
            { name: "People", elementType: Person },
            { name: "StatusSet", elementType: StatusSet },
            { name: "Tickets", elementType: Ticket },
            { name: "TicketTypes", elementType: TicketType },
            { name: "WorklistItems", elementType: WorklistItem }
        ], [
            {
                name: "Areas_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Areas },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/Areas(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "AreasByOrgID", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Areas },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/AreasByOrgID()",
                        {
                            Id: $toODataString(Id, "Int32?")
                        });
                }
            },
            {
                name: "Environments_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Environments },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/Environments(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "EnvByOrgId", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Environments },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/EnvByOrgId()",
                        {
                            Id: $toODataString(Id, "Int32?")
                        });
                }
            },
            {
                name: "LogEntries_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.LogEntries },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/LogEntries(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "LogTypes_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.LogTypes },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/LogTypes(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "Organizations_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Organizations },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/Organizations(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "People_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.People },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/People(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "StatusSet_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.StatusSet },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/StatusSet(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "StatusByOrgId", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.StatusSet },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/StatusByOrgId()",
                        {
                            Id: $toODataString(Id, "Int32?")
                        });
                }
            },
            {
                name: "Tickets_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Tickets },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/Tickets(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "TicketByID", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.Tickets },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/TicketByID()",
                        {
                            Id: $toODataString(Id, "Int32?")
                        });
                }
            },
            {
                name: "TicketTypes_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.TicketTypes },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/TicketTypes(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "WorklistItems_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.WorklistItems },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/WorklistItems(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "WorklistItemsByOrgId", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.WorklistItems },
                        lightSwitchApplication.rootUri + "/CoWoItData.svc" + "/WorklistItemsByOrgId()",
                        {
                            Id: $toODataString(Id, "Int32?")
                        });
                }
            }
        ]),

        DataWorkspace: $defineDataWorkspace(DataWorkspace, [
            { name: "CoWoItData", type: CoWoItData }
        ])

    });

}(msls.application));
