﻿/// <reference path="data.js" />

(function (lightSwitchApplication) {

    var $Screen = msls.Screen,
        $defineScreen = msls._defineScreen,
        $DataServiceQuery = msls.DataServiceQuery,
        $toODataString = msls._toODataString,
        $defineShowScreen = msls._defineShowScreen;

    function AddEditArea(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditArea screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Area" type="msls.application.Area">
        /// Gets or sets the area for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditArea.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditArea", parameters);
    }

    function AddEditEnvironment(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditEnvironment screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Environment" type="msls.application.Environment">
        /// Gets or sets the environment for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditEnvironment.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditEnvironment", parameters);
    }

    function AddEditOrg(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditOrg screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditOrg.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditOrg", parameters);
    }

    function AddEditPerson(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditPerson screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Person" type="msls.application.Person">
        /// Gets or sets the person for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditPerson.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditPerson", parameters);
    }

    function AddEditStatusSet(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditStatusSet screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="StatusSet" type="msls.application.StatusSet">
        /// Gets or sets the statusSet for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditStatusSet.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditStatusSet", parameters);
    }

    function AddEditTicketType(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditTicketType screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="TicketType" type="msls.application.TicketType">
        /// Gets or sets the ticketType for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditTicketType.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditTicketType", parameters);
    }

    function BrowseAdmin(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseAdmin screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Organizations" type="msls.VisualCollection" elementType="msls.application.Organization">
        /// Gets the organizations for this screen.
        /// </field>
        /// <field name="People" type="msls.VisualCollection" elementType="msls.application.Person">
        /// Gets the people for this screen.
        /// </field>
        /// <field name="LogTypes" type="msls.VisualCollection" elementType="msls.application.LogType">
        /// Gets the logTypes for this screen.
        /// </field>
        /// <field name="TicketTypes" type="msls.VisualCollection" elementType="msls.application.TicketType">
        /// Gets the ticketTypes for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseAdmin.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseAdmin", parameters);
    }

    function ViewOrg(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewOrg screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Organization" type="msls.application.Organization">
        /// Gets or sets the organization for this screen.
        /// </field>
        /// <field name="Areas" type="msls.VisualCollection" elementType="msls.application.Area">
        /// Gets the areas for this screen.
        /// </field>
        /// <field name="Environments" type="msls.VisualCollection" elementType="msls.application.Environment">
        /// Gets the environments for this screen.
        /// </field>
        /// <field name="StatusSet" type="msls.VisualCollection" elementType="msls.application.StatusSet">
        /// Gets the statusSet for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewOrg.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewOrg", parameters);
    }

    function BrowseWorklistItems(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseWorklistItems screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItems" type="msls.VisualCollection" elementType="msls.application.WorklistItem">
        /// Gets the worklistItems for this screen.
        /// </field>
        /// <field name="TicketByID" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the ticketByID for this screen.
        /// </field>
        /// <field name="LogEntries" type="msls.VisualCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this screen.
        /// </field>
        /// <field name="Tickets" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this screen.
        /// </field>
        /// <field name="OrgSel" type="msls.application.Organization">
        /// Gets or sets the orgSel for this screen.
        /// </field>
        /// <field name="PeopleSel" type="msls.application.Person">
        /// Gets or sets the peopleSel for this screen.
        /// </field>
        /// <field name="StatusByOrgId" type="msls.VisualCollection" elementType="msls.application.StatusSet">
        /// Gets the statusByOrgId for this screen.
        /// </field>
        /// <field name="Statuses" type="msls.application.StatusSet">
        /// Gets or sets the statuses for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseWorklistItems.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseWorklistItems", parameters);
    }

    function NewWorklistItem(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the NewWorklistItem screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this screen.
        /// </field>
        /// <field name="AreasByOrgID" type="msls.VisualCollection" elementType="msls.application.Area">
        /// Gets the areasByOrgID for this screen.
        /// </field>
        /// <field name="EnvByOrgId" type="msls.VisualCollection" elementType="msls.application.Environment">
        /// Gets the envByOrgId for this screen.
        /// </field>
        /// <field name="StatusByOrgId" type="msls.VisualCollection" elementType="msls.application.StatusSet">
        /// Gets the statusByOrgId for this screen.
        /// </field>
        /// <field name="details" type="msls.application.NewWorklistItem.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "NewWorklistItem", parameters);
    }

    function ViewWorklistItem(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewWorklistItem screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this screen.
        /// </field>
        /// <field name="LogEntries" type="msls.VisualCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this screen.
        /// </field>
        /// <field name="Tickets" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewWorklistItem.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewWorklistItem", parameters);
    }

    function AddEditLogEntry(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditLogEntry screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="LogEntry" type="msls.application.LogEntry">
        /// Gets or sets the logEntry for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditLogEntry.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditLogEntry", parameters);
    }

    function AddEditTicket(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditTicket screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Ticket" type="msls.application.Ticket">
        /// Gets or sets the ticket for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditTicket.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditTicket", parameters);
    }

    function AddEditLogType(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditLogType screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="LogType" type="msls.application.LogType">
        /// Gets or sets the logType for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditLogType.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditLogType", parameters);
    }

    function AddEditWorklistItem(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditWorklistItem screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="WorklistItem" type="msls.application.WorklistItem">
        /// Gets or sets the worklistItem for this screen.
        /// </field>
        /// <field name="LogEntries" type="msls.VisualCollection" elementType="msls.application.LogEntry">
        /// Gets the logEntries for this screen.
        /// </field>
        /// <field name="Tickets" type="msls.VisualCollection" elementType="msls.application.Ticket">
        /// Gets the tickets for this screen.
        /// </field>
        /// <field name="StatusByOrgId" type="msls.VisualCollection" elementType="msls.application.StatusSet">
        /// Gets the statusByOrgId for this screen.
        /// </field>
        /// <field name="EnvByOrgId" type="msls.VisualCollection" elementType="msls.application.Environment">
        /// Gets the envByOrgId for this screen.
        /// </field>
        /// <field name="AreasByOrgID" type="msls.VisualCollection" elementType="msls.application.Area">
        /// Gets the areasByOrgID for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditWorklistItem.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditWorklistItem", parameters);
    }

    msls._addToNamespace("msls.application", {

        AddEditArea: $defineScreen(AddEditArea, [
            { name: "Area", kind: "local", type: lightSwitchApplication.Area }
        ], [
        ]),

        AddEditEnvironment: $defineScreen(AddEditEnvironment, [
            { name: "Environment", kind: "local", type: lightSwitchApplication.Environment }
        ], [
        ]),

        AddEditOrg: $defineScreen(AddEditOrg, [
            { name: "Organization", kind: "local", type: lightSwitchApplication.Organization }
        ], [
        ]),

        AddEditPerson: $defineScreen(AddEditPerson, [
            { name: "Person", kind: "local", type: lightSwitchApplication.Person }
        ], [
        ]),

        AddEditStatusSet: $defineScreen(AddEditStatusSet, [
            { name: "StatusSet", kind: "local", type: lightSwitchApplication.StatusSet }
        ], [
        ]),

        AddEditTicketType: $defineScreen(AddEditTicketType, [
            { name: "TicketType", kind: "local", type: lightSwitchApplication.TicketType }
        ], [
        ]),

        BrowseAdmin: $defineScreen(BrowseAdmin, [
            {
                name: "Organizations", kind: "collection", elementType: lightSwitchApplication.Organization,
                createQuery: function () {
                    return this.dataWorkspace.CoWoItData.Organizations;
                }
            },
            {
                name: "People", kind: "collection", elementType: lightSwitchApplication.Person,
                createQuery: function () {
                    return this.dataWorkspace.CoWoItData.People;
                }
            },
            {
                name: "LogTypes", kind: "collection", elementType: lightSwitchApplication.LogType,
                createQuery: function () {
                    return this.dataWorkspace.CoWoItData.LogTypes;
                }
            },
            {
                name: "TicketTypes", kind: "collection", elementType: lightSwitchApplication.TicketType,
                createQuery: function () {
                    return this.dataWorkspace.CoWoItData.TicketTypes;
                }
            }
        ], [
        ]),

        ViewOrg: $defineScreen(ViewOrg, [
            { name: "Organization", kind: "local", type: lightSwitchApplication.Organization },
            {
                name: "Areas", kind: "collection", elementType: lightSwitchApplication.Area,
                getNavigationProperty: function () {
                    if (this.owner.Organization) {
                        return this.owner.Organization.details.properties.Areas;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            },
            {
                name: "Environments", kind: "collection", elementType: lightSwitchApplication.Environment,
                getNavigationProperty: function () {
                    if (this.owner.Organization) {
                        return this.owner.Organization.details.properties.Environments;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            },
            {
                name: "StatusSet", kind: "collection", elementType: lightSwitchApplication.StatusSet,
                getNavigationProperty: function () {
                    if (this.owner.Organization) {
                        return this.owner.Organization.details.properties.StatusSet;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            }
        ], [
        ]),

        BrowseWorklistItems: $defineScreen(BrowseWorklistItems, [
            {
                name: "WorklistItems", kind: "collection", elementType: lightSwitchApplication.WorklistItem,
                createQuery: function (Org, PersonId, StatusId) {
                    return this.dataWorkspace.CoWoItData.WorklistItems.filter("(" + ((Org === undefined || Org === null) ? "true" : "(Organization/Id eq " + $toODataString(Org, "Int32?") + ")") + " and " + ((PersonId === undefined || PersonId === null) ? "true" : "(Person/Id eq " + $toODataString(PersonId, "Int32?") + ")") + ") and " + ((StatusId === undefined || StatusId === null) ? "true" : "(StatusSet/Id eq " + $toODataString(StatusId, "Int32?") + ")") + "").expand("Person").expand("StatusSet").expand("Area").expand("Environment");
                }
            },
            {
                name: "TicketByID", kind: "collection", elementType: lightSwitchApplication.Ticket,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.TicketByID(Id);
                }
            },
            {
                name: "LogEntries", kind: "collection", elementType: lightSwitchApplication.LogEntry,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItems.selectedItem) {
                        return this.owner.WorklistItems.selectedItem.details.properties.LogEntries;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            },
            {
                name: "Tickets", kind: "collection", elementType: lightSwitchApplication.Ticket,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItems.selectedItem) {
                        return this.owner.WorklistItems.selectedItem.details.properties.Tickets;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("TicketType");
                }
            },
            { name: "OrgSel", kind: "local", type: lightSwitchApplication.Organization },
            { name: "PeopleSel", kind: "local", type: lightSwitchApplication.Person },
            {
                name: "StatusByOrgId", kind: "collection", elementType: lightSwitchApplication.StatusSet,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.StatusByOrgId(Id);
                }
            },
            { name: "Statuses", kind: "local", type: lightSwitchApplication.StatusSet }
        ], [
            { name: "DeleteSelectedWorklistItem" }
        ]),

        NewWorklistItem: $defineScreen(NewWorklistItem, [
            { name: "WorklistItem", kind: "local", type: lightSwitchApplication.WorklistItem },
            {
                name: "AreasByOrgID", kind: "collection", elementType: lightSwitchApplication.Area,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.AreasByOrgID(Id);
                }
            },
            {
                name: "EnvByOrgId", kind: "collection", elementType: lightSwitchApplication.Environment,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.EnvByOrgId(Id);
                }
            },
            {
                name: "StatusByOrgId", kind: "collection", elementType: lightSwitchApplication.StatusSet,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.StatusByOrgId(Id);
                }
            }
        ], [
            { name: "ShowStep2" },
            { name: "ShowStep3" },
            { name: "Finish" }
        ]),

        ViewWorklistItem: $defineScreen(ViewWorklistItem, [
            { name: "WorklistItem", kind: "local", type: lightSwitchApplication.WorklistItem },
            {
                name: "LogEntries", kind: "collection", elementType: lightSwitchApplication.LogEntry,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.LogEntries;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            },
            {
                name: "Tickets", kind: "collection", elementType: lightSwitchApplication.Ticket,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.Tickets;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("TicketType");
                }
            }
        ], [
        ]),

        AddEditLogEntry: $defineScreen(AddEditLogEntry, [
            { name: "LogEntry", kind: "local", type: lightSwitchApplication.LogEntry }
        ], [
        ]),

        AddEditTicket: $defineScreen(AddEditTicket, [
            { name: "Ticket", kind: "local", type: lightSwitchApplication.Ticket }
        ], [
            { name: "DeleteTicket" }
        ]),

        AddEditLogType: $defineScreen(AddEditLogType, [
            { name: "LogType", kind: "local", type: lightSwitchApplication.LogType }
        ], [
        ]),

        AddEditWorklistItem: $defineScreen(AddEditWorklistItem, [
            { name: "WorklistItem", kind: "local", type: lightSwitchApplication.WorklistItem },
            {
                name: "LogEntries", kind: "collection", elementType: lightSwitchApplication.LogEntry,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.LogEntries;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this;
                }
            },
            {
                name: "Tickets", kind: "collection", elementType: lightSwitchApplication.Ticket,
                getNavigationProperty: function () {
                    if (this.owner.WorklistItem) {
                        return this.owner.WorklistItem.details.properties.Tickets;
                    }
                    return null;
                },
                appendQuery: function () {
                    return this.expand("TicketType");
                }
            },
            {
                name: "StatusByOrgId", kind: "collection", elementType: lightSwitchApplication.StatusSet,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.StatusByOrgId(Id);
                }
            },
            {
                name: "EnvByOrgId", kind: "collection", elementType: lightSwitchApplication.Environment,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.EnvByOrgId(Id);
                }
            },
            {
                name: "AreasByOrgID", kind: "collection", elementType: lightSwitchApplication.Area,
                createQuery: function (Id) {
                    return this.dataWorkspace.CoWoItData.AreasByOrgID(Id);
                }
            }
        ], [
            { name: "DeleteThisWorklist" }
        ]),

        showAddEditArea: $defineShowScreen(function showAddEditArea(Area, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditArea screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditArea", parameters, options);
        }),

        showAddEditEnvironment: $defineShowScreen(function showAddEditEnvironment(Environment, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditEnvironment screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditEnvironment", parameters, options);
        }),

        showAddEditOrg: $defineShowScreen(function showAddEditOrg(Organization, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditOrg screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditOrg", parameters, options);
        }),

        showAddEditPerson: $defineShowScreen(function showAddEditPerson(Person, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditPerson screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditPerson", parameters, options);
        }),

        showAddEditStatusSet: $defineShowScreen(function showAddEditStatusSet(StatusSet, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditStatusSet screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditStatusSet", parameters, options);
        }),

        showAddEditTicketType: $defineShowScreen(function showAddEditTicketType(TicketType, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditTicketType screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditTicketType", parameters, options);
        }),

        showBrowseAdmin: $defineShowScreen(function showBrowseAdmin(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseAdmin screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseAdmin", parameters, options);
        }),

        showViewOrg: $defineShowScreen(function showViewOrg(Organization, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewOrg screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewOrg", parameters, options);
        }),

        showBrowseWorklistItems: $defineShowScreen(function showBrowseWorklistItems(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseWorklistItems screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseWorklistItems", parameters, options);
        }),

        showNewWorklistItem: $defineShowScreen(function showNewWorklistItem(WorklistItem, options) {
            /// <summary>
            /// Asynchronously navigates forward to the NewWorklistItem screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("NewWorklistItem", parameters, options);
        }),

        showViewWorklistItem: $defineShowScreen(function showViewWorklistItem(WorklistItem, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewWorklistItem screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewWorklistItem", parameters, options);
        }),

        showAddEditLogEntry: $defineShowScreen(function showAddEditLogEntry(LogEntry, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditLogEntry screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditLogEntry", parameters, options);
        }),

        showAddEditTicket: $defineShowScreen(function showAddEditTicket(Ticket, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditTicket screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditTicket", parameters, options);
        }),

        showAddEditLogType: $defineShowScreen(function showAddEditLogType(LogType, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditLogType screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditLogType", parameters, options);
        }),

        showAddEditWorklistItem: $defineShowScreen(function showAddEditWorklistItem(WorklistItem, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditWorklistItem screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditWorklistItem", parameters, options);
        })

    });

}(msls.application));
