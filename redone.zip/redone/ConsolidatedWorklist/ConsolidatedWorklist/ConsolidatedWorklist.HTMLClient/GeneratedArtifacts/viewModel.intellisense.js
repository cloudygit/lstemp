﻿/// <reference path="viewModel.js" />

(function (lightSwitchApplication) {

    var $element = document.createElement("div");

    lightSwitchApplication.AddEditArea.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditArea
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.AddEditArea,
            value: lightSwitchApplication.AddEditArea
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.AddEditArea,
            value: lightSwitchApplication.Area
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.Area,
            value: String
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditArea,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Organization
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditArea
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditArea, {
        /// <field>
        /// Called when a new AddEditArea screen is created.
        /// <br/>created(msls.application.AddEditArea screen)
        /// </field>
        created: [lightSwitchApplication.AddEditArea],
        /// <field>
        /// Called before changes on an active AddEditArea screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditArea screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditArea],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("Name"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.AddEditArea().findContentItem("Organization"); }]
    });

    lightSwitchApplication.AddEditEnvironment.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditEnvironment
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.AddEditEnvironment,
            value: lightSwitchApplication.AddEditEnvironment
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.AddEditEnvironment,
            value: lightSwitchApplication.Environment
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: String
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditEnvironment,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Organization
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditEnvironment
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditEnvironment, {
        /// <field>
        /// Called when a new AddEditEnvironment screen is created.
        /// <br/>created(msls.application.AddEditEnvironment screen)
        /// </field>
        created: [lightSwitchApplication.AddEditEnvironment],
        /// <field>
        /// Called before changes on an active AddEditEnvironment screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditEnvironment screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditEnvironment],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("Name"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.AddEditEnvironment().findContentItem("Organization"); }]
    });

    lightSwitchApplication.AddEditOrg.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditOrg
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditOrg,
            data: lightSwitchApplication.AddEditOrg,
            value: lightSwitchApplication.AddEditOrg
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditOrg,
            data: lightSwitchApplication.AddEditOrg,
            value: lightSwitchApplication.Organization
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditOrg,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditOrg,
            data: lightSwitchApplication.Organization,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditOrg
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditOrg, {
        /// <field>
        /// Called when a new AddEditOrg screen is created.
        /// <br/>created(msls.application.AddEditOrg screen)
        /// </field>
        created: [lightSwitchApplication.AddEditOrg],
        /// <field>
        /// Called before changes on an active AddEditOrg screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditOrg screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditOrg],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrg().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrg().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrg().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditOrg().findContentItem("Name"); }]
    });

    lightSwitchApplication.AddEditPerson.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditPerson
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.AddEditPerson,
            value: lightSwitchApplication.AddEditPerson
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.AddEditPerson,
            value: lightSwitchApplication.Person
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        DisplayName: {
            _$class: msls.ContentItem,
            _$name: "DisplayName",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditPerson,
            data: lightSwitchApplication.Person,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditPerson
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditPerson, {
        /// <field>
        /// Called when a new AddEditPerson screen is created.
        /// <br/>created(msls.application.AddEditPerson screen)
        /// </field>
        created: [lightSwitchApplication.AddEditPerson],
        /// <field>
        /// Called before changes on an active AddEditPerson screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditPerson screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditPerson],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("left"); }],
        /// <field>
        /// Called after the DisplayName content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DisplayName_postRender: [$element, function () { return new lightSwitchApplication.AddEditPerson().findContentItem("DisplayName"); }]
    });

    lightSwitchApplication.AddEditStatusSet.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditStatusSet
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.AddEditStatusSet,
            value: lightSwitchApplication.AddEditStatusSet
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.AddEditStatusSet,
            value: lightSwitchApplication.StatusSet
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.StatusSet
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: String
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: Date
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.StatusSet
        },
        ModifiedBy: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: String
        },
        Modified: {
            _$class: msls.ContentItem,
            _$name: "Modified",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: Date
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditStatusSet,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.Organization
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditStatusSet
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditStatusSet, {
        /// <field>
        /// Called when a new AddEditStatusSet screen is created.
        /// <br/>created(msls.application.AddEditStatusSet screen)
        /// </field>
        created: [lightSwitchApplication.AddEditStatusSet],
        /// <field>
        /// Called before changes on an active AddEditStatusSet screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditStatusSet screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditStatusSet],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("Name"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("Created"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("right"); }],
        /// <field>
        /// Called after the ModifiedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("ModifiedBy"); }],
        /// <field>
        /// Called after the Modified content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("Modified"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.AddEditStatusSet().findContentItem("Organization"); }]
    });

    lightSwitchApplication.AddEditTicketType.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditTicketType
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.AddEditTicketType,
            value: lightSwitchApplication.AddEditTicketType
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.AddEditTicketType,
            value: lightSwitchApplication.TicketType
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: lightSwitchApplication.TicketType
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: String
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicketType,
            data: lightSwitchApplication.TicketType,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditTicketType
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditTicketType, {
        /// <field>
        /// Called when a new AddEditTicketType screen is created.
        /// <br/>created(msls.application.AddEditTicketType screen)
        /// </field>
        created: [lightSwitchApplication.AddEditTicketType],
        /// <field>
        /// Called before changes on an active AddEditTicketType screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditTicketType screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditTicketType],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("Name"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicketType().findContentItem("Created"); }]
    });

    lightSwitchApplication.BrowseAdmin.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseAdmin
        },
        AdminList: {
            _$class: msls.ContentItem,
            _$name: "AdminList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: lightSwitchApplication.BrowseAdmin
        },
        Organizations: {
            _$class: msls.ContentItem,
            _$name: "Organizations",
            _$parentName: "AdminList",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseAdmin,
                _$entry: {
                    elementType: lightSwitchApplication.Organization
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "Organizations",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Organization,
            value: String
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Organization,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Organization,
            value: Date
        },
        Group1: {
            _$class: msls.ContentItem,
            _$name: "Group1",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: lightSwitchApplication.BrowseAdmin
        },
        People: {
            _$class: msls.ContentItem,
            _$name: "People",
            _$parentName: "Group1",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseAdmin,
                _$entry: {
                    elementType: lightSwitchApplication.Person
                }
            }
        },
        PeopleTemplate: {
            _$class: msls.ContentItem,
            _$name: "PeopleTemplate",
            _$parentName: "People",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        DisplayName: {
            _$class: msls.ContentItem,
            _$name: "DisplayName",
            _$parentName: "PeopleTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Person,
            value: String
        },
        CreatedBy2: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy2",
            _$parentName: "PeopleTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Person,
            value: String
        },
        Created2: {
            _$class: msls.ContentItem,
            _$name: "Created2",
            _$parentName: "PeopleTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Person,
            value: Date
        },
        ModifiedBy1: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy1",
            _$parentName: "PeopleTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Person,
            value: String
        },
        Modified1: {
            _$class: msls.ContentItem,
            _$name: "Modified1",
            _$parentName: "PeopleTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.Person,
            value: Date
        },
        Group2: {
            _$class: msls.ContentItem,
            _$name: "Group2",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: lightSwitchApplication.BrowseAdmin
        },
        TicketTypes: {
            _$class: msls.ContentItem,
            _$name: "TicketTypes",
            _$parentName: "Group2",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseAdmin,
                _$entry: {
                    elementType: lightSwitchApplication.TicketType
                }
            }
        },
        TicketTypesTemplate: {
            _$class: msls.ContentItem,
            _$name: "TicketTypesTemplate",
            _$parentName: "TicketTypes",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.TicketType,
            value: lightSwitchApplication.TicketType
        },
        Name1: {
            _$class: msls.ContentItem,
            _$name: "Name1",
            _$parentName: "TicketTypesTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.TicketType,
            value: String
        },
        CreatedBy1: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy1",
            _$parentName: "TicketTypesTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.TicketType,
            value: String
        },
        Created1: {
            _$class: msls.ContentItem,
            _$name: "Created1",
            _$parentName: "TicketTypesTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.TicketType,
            value: Date
        },
        ModifiedBy: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy",
            _$parentName: "TicketTypesTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.TicketType,
            value: String
        },
        Modified: {
            _$class: msls.ContentItem,
            _$name: "Modified",
            _$parentName: "TicketTypesTemplate",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.TicketType,
            value: Date
        },
        LogTypes: {
            _$class: msls.ContentItem,
            _$name: "LogTypes",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: lightSwitchApplication.BrowseAdmin
        },
        LogTypes1: {
            _$class: msls.ContentItem,
            _$name: "LogTypes1",
            _$parentName: "LogTypes",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.BrowseAdmin,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseAdmin,
                _$entry: {
                    elementType: lightSwitchApplication.LogType
                }
            }
        },
        LogTypes1Template: {
            _$class: msls.ContentItem,
            _$name: "LogTypes1Template",
            _$parentName: "LogTypes1",
            screen: lightSwitchApplication.BrowseAdmin,
            data: lightSwitchApplication.LogType,
            value: lightSwitchApplication.LogType
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseAdmin
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseAdmin, {
        /// <field>
        /// Called when a new BrowseAdmin screen is created.
        /// <br/>created(msls.application.BrowseAdmin screen)
        /// </field>
        created: [lightSwitchApplication.BrowseAdmin],
        /// <field>
        /// Called before changes on an active BrowseAdmin screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseAdmin screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseAdmin],
        /// <field>
        /// Called after the AdminList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AdminList_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("AdminList"); }],
        /// <field>
        /// Called after the Organizations content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organizations_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Organizations"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("rows"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Name"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Created"); }],
        /// <field>
        /// Called after the Group1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Group1"); }],
        /// <field>
        /// Called after the People content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        People_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("People"); }],
        /// <field>
        /// Called after the PeopleTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        PeopleTemplate_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("PeopleTemplate"); }],
        /// <field>
        /// Called after the DisplayName content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DisplayName_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("DisplayName"); }],
        /// <field>
        /// Called after the CreatedBy2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy2_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("CreatedBy2"); }],
        /// <field>
        /// Called after the Created2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created2_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Created2"); }],
        /// <field>
        /// Called after the ModifiedBy1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("ModifiedBy1"); }],
        /// <field>
        /// Called after the Modified1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Modified1"); }],
        /// <field>
        /// Called after the Group2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group2_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Group2"); }],
        /// <field>
        /// Called after the TicketTypes content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketTypes_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("TicketTypes"); }],
        /// <field>
        /// Called after the TicketTypesTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketTypesTemplate_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("TicketTypesTemplate"); }],
        /// <field>
        /// Called after the Name1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Name1"); }],
        /// <field>
        /// Called after the CreatedBy1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("CreatedBy1"); }],
        /// <field>
        /// Called after the Created1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Created1"); }],
        /// <field>
        /// Called after the ModifiedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("ModifiedBy"); }],
        /// <field>
        /// Called after the Modified content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("Modified"); }],
        /// <field>
        /// Called after the LogTypes content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogTypes_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("LogTypes"); }],
        /// <field>
        /// Called after the LogTypes1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogTypes1_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("LogTypes1"); }],
        /// <field>
        /// Called after the LogTypes1Template content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogTypes1Template_postRender: [$element, function () { return new lightSwitchApplication.BrowseAdmin().findContentItem("LogTypes1Template"); }]
    });

    lightSwitchApplication.ViewOrg.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewOrg
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: lightSwitchApplication.ViewOrg
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: lightSwitchApplication.Organization
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: String
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: Date
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        ModifiedBy: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: String
        },
        Modified: {
            _$class: msls.ContentItem,
            _$name: "Modified",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Organization,
            value: Date
        },
        Areas: {
            _$class: msls.ContentItem,
            _$name: "Areas",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: lightSwitchApplication.ViewOrg
        },
        Areas1: {
            _$class: msls.ContentItem,
            _$name: "Areas1",
            _$parentName: "Areas",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewOrg,
                _$entry: {
                    elementType: lightSwitchApplication.Area
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "Areas1",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        Name1: {
            _$class: msls.ContentItem,
            _$name: "Name1",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Area,
            value: String
        },
        CreatedBy1: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy1",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Area,
            value: String
        },
        Created1: {
            _$class: msls.ContentItem,
            _$name: "Created1",
            _$parentName: "rows",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Area,
            value: Date
        },
        Environments: {
            _$class: msls.ContentItem,
            _$name: "Environments",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: lightSwitchApplication.ViewOrg
        },
        Environments1: {
            _$class: msls.ContentItem,
            _$name: "Environments1",
            _$parentName: "Environments",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewOrg,
                _$entry: {
                    elementType: lightSwitchApplication.Environment
                }
            }
        },
        rows1: {
            _$class: msls.ContentItem,
            _$name: "rows1",
            _$parentName: "Environments1",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Name2: {
            _$class: msls.ContentItem,
            _$name: "Name2",
            _$parentName: "rows1",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Environment,
            value: String
        },
        CreatedBy2: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy2",
            _$parentName: "rows1",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Environment,
            value: String
        },
        Created2: {
            _$class: msls.ContentItem,
            _$name: "Created2",
            _$parentName: "rows1",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.Environment,
            value: Date
        },
        StatusSet: {
            _$class: msls.ContentItem,
            _$name: "StatusSet",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: lightSwitchApplication.ViewOrg
        },
        StatusSet1: {
            _$class: msls.ContentItem,
            _$name: "StatusSet1",
            _$parentName: "StatusSet",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.ViewOrg,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewOrg,
                _$entry: {
                    elementType: lightSwitchApplication.StatusSet
                }
            }
        },
        rows2: {
            _$class: msls.ContentItem,
            _$name: "rows2",
            _$parentName: "StatusSet1",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.StatusSet
        },
        Name3: {
            _$class: msls.ContentItem,
            _$name: "Name3",
            _$parentName: "rows2",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.StatusSet,
            value: String
        },
        CreatedBy3: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy3",
            _$parentName: "rows2",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.StatusSet,
            value: String
        },
        Created3: {
            _$class: msls.ContentItem,
            _$name: "Created3",
            _$parentName: "rows2",
            screen: lightSwitchApplication.ViewOrg,
            data: lightSwitchApplication.StatusSet,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewOrg
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewOrg, {
        /// <field>
        /// Called when a new ViewOrg screen is created.
        /// <br/>created(msls.application.ViewOrg screen)
        /// </field>
        created: [lightSwitchApplication.ViewOrg],
        /// <field>
        /// Called before changes on an active ViewOrg screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewOrg screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewOrg],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Name"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Created"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("right"); }],
        /// <field>
        /// Called after the ModifiedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("ModifiedBy"); }],
        /// <field>
        /// Called after the Modified content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Modified"); }],
        /// <field>
        /// Called after the Areas content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Areas_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Areas"); }],
        /// <field>
        /// Called after the Areas1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Areas1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Areas1"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("rows"); }],
        /// <field>
        /// Called after the Name1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Name1"); }],
        /// <field>
        /// Called after the CreatedBy1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("CreatedBy1"); }],
        /// <field>
        /// Called after the Created1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Created1"); }],
        /// <field>
        /// Called after the Environments content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environments_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Environments"); }],
        /// <field>
        /// Called after the Environments1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environments1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Environments1"); }],
        /// <field>
        /// Called after the rows1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("rows1"); }],
        /// <field>
        /// Called after the Name2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Name2"); }],
        /// <field>
        /// Called after the CreatedBy2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("CreatedBy2"); }],
        /// <field>
        /// Called after the Created2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Created2"); }],
        /// <field>
        /// Called after the StatusSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("StatusSet"); }],
        /// <field>
        /// Called after the StatusSet1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet1_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("StatusSet1"); }],
        /// <field>
        /// Called after the rows2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows2_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("rows2"); }],
        /// <field>
        /// Called after the Name3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Name3"); }],
        /// <field>
        /// Called after the CreatedBy3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("CreatedBy3"); }],
        /// <field>
        /// Called after the Created3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created3_postRender: [$element, function () { return new lightSwitchApplication.ViewOrg().findContentItem("Created3"); }]
    });

    lightSwitchApplication.BrowseWorklistItems.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseWorklistItems
        },
        WorklistItemList: {
            _$class: msls.ContentItem,
            _$name: "WorklistItemList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        Group: {
            _$class: msls.ContentItem,
            _$name: "Group",
            _$parentName: "WorklistItemList",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        WorklistItems: {
            _$class: msls.ContentItem,
            _$name: "WorklistItems",
            _$parentName: "Group",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseWorklistItems,
                _$entry: {
                    elementType: lightSwitchApplication.WorklistItem
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "WorklistItems",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Person
        },
        StatusSet: {
            _$class: msls.ContentItem,
            _$name: "StatusSet",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.StatusSet
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Area
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        Group1: {
            _$class: msls.ContentItem,
            _$name: "Group1",
            _$parentName: "Group",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        WorklistItems_selectedItem_Description: {
            _$class: msls.ContentItem,
            _$name: "WorklistItems_selectedItem_Description",
            _$parentName: "Group1",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: String
        },
        Tickets: {
            _$class: msls.ContentItem,
            _$name: "Tickets",
            _$parentName: "Group1",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseWorklistItems,
                _$entry: {
                    elementType: lightSwitchApplication.Ticket
                }
            }
        },
        TicketsTemplate: {
            _$class: msls.ContentItem,
            _$name: "TicketsTemplate",
            _$parentName: "Tickets",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketType2: {
            _$class: msls.ContentItem,
            _$name: "TicketType2",
            _$parentName: "TicketsTemplate",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.TicketType
        },
        TicketNumber1: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber1",
            _$parentName: "TicketsTemplate",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        DateCreated1: {
            _$class: msls.ContentItem,
            _$name: "DateCreated1",
            _$parentName: "TicketsTemplate",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        AddTicket: {
            _$class: msls.ContentItem,
            _$name: "AddTicket",
            _$parentName: "Group1",
            screen: lightSwitchApplication.BrowseWorklistItems
        },
        LogEntries: {
            _$class: msls.ContentItem,
            _$name: "LogEntries",
            _$parentName: "Group1",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseWorklistItems,
                _$entry: {
                    elementType: lightSwitchApplication.LogEntry
                }
            }
        },
        LogEntriesTemplate: {
            _$class: msls.ContentItem,
            _$name: "LogEntriesTemplate",
            _$parentName: "LogEntries",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogEntry
        },
        Entry: {
            _$class: msls.ContentItem,
            _$name: "Entry",
            _$parentName: "LogEntriesTemplate",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "LogEntriesTemplate",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.LogEntry,
            value: Date
        },
        ShowAddEditLogEntry: {
            _$class: msls.ContentItem,
            _$name: "ShowAddEditLogEntry",
            _$parentName: "Group1",
            screen: lightSwitchApplication.BrowseWorklistItems
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseWorklistItems
        },
        FilterModal: {
            _$class: msls.ContentItem,
            _$name: "FilterModal",
            _$parentName: "Popups",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.BrowseWorklistItems
        },
        OrgSel: {
            _$class: msls.ContentItem,
            _$name: "OrgSel",
            _$parentName: "FilterModal",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Organization
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "OrgSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        Statuses: {
            _$class: msls.ContentItem,
            _$name: "Statuses",
            _$parentName: "FilterModal",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.StatusSet
        },
        StatusSet2: {
            _$class: msls.ContentItem,
            _$name: "StatusSet2",
            _$parentName: "Statuses",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.StatusSet
        },
        PeopleSel: {
            _$class: msls.ContentItem,
            _$name: "PeopleSel",
            _$parentName: "FilterModal",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.BrowseWorklistItems,
            value: lightSwitchApplication.Person
        },
        Person2: {
            _$class: msls.ContentItem,
            _$name: "Person2",
            _$parentName: "PeopleSel",
            screen: lightSwitchApplication.BrowseWorklistItems,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseWorklistItems, {
        /// <field>
        /// Called when a new BrowseWorklistItems screen is created.
        /// <br/>created(msls.application.BrowseWorklistItems screen)
        /// </field>
        created: [lightSwitchApplication.BrowseWorklistItems],
        /// <field>
        /// Called before changes on an active BrowseWorklistItems screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseWorklistItems screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseWorklistItems],
        /// <field>
        /// Called to determine if the DeleteSelectedWorklistItem method can be executed.
        /// <br/>canExecute(msls.application.BrowseWorklistItems screen)
        /// </field>
        DeleteSelectedWorklistItem_canExecute: [lightSwitchApplication.BrowseWorklistItems],
        /// <field>
        /// Called to execute the DeleteSelectedWorklistItem method.
        /// <br/>execute(msls.application.BrowseWorklistItems screen)
        /// </field>
        DeleteSelectedWorklistItem_execute: [lightSwitchApplication.BrowseWorklistItems],
        /// <field>
        /// Called after the WorklistItemList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItemList_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("WorklistItemList"); }],
        /// <field>
        /// Called after the Group content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Group"); }],
        /// <field>
        /// Called after the WorklistItems content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItems_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("WorklistItems"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("rows"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Name"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Person"); }],
        /// <field>
        /// Called after the StatusSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("StatusSet"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Area"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Environment"); }],
        /// <field>
        /// Called after the Group1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group1_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Group1"); }],
        /// <field>
        /// Called after the WorklistItems_selectedItem_Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItems_selectedItem_Description_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("WorklistItems_selectedItem_Description"); }],
        /// <field>
        /// Called after the Tickets content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Tickets_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Tickets"); }],
        /// <field>
        /// Called after the TicketsTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketsTemplate_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("TicketsTemplate"); }],
        /// <field>
        /// Called after the TicketType2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType2_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("TicketType2"); }],
        /// <field>
        /// Called after the TicketNumber1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber1_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("TicketNumber1"); }],
        /// <field>
        /// Called after the DateCreated1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated1_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("DateCreated1"); }],
        /// <field>
        /// Called after the AddTicket content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AddTicket_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("AddTicket"); }],
        /// <field>
        /// Called after the LogEntries content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntries_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("LogEntries"); }],
        /// <field>
        /// Called after the LogEntriesTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntriesTemplate_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("LogEntriesTemplate"); }],
        /// <field>
        /// Called after the Entry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Entry_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Entry"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Created"); }],
        /// <field>
        /// Called after the ShowAddEditLogEntry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ShowAddEditLogEntry_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("ShowAddEditLogEntry"); }],
        /// <field>
        /// Called after the FilterModal content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        FilterModal_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("FilterModal"); }],
        /// <field>
        /// Called after the OrgSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        OrgSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("OrgSel"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Organization"); }],
        /// <field>
        /// Called after the Statuses content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Statuses_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Statuses"); }],
        /// <field>
        /// Called after the StatusSet2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet2_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("StatusSet2"); }],
        /// <field>
        /// Called after the PeopleSel content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        PeopleSel_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("PeopleSel"); }],
        /// <field>
        /// Called after the Person2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person2_postRender: [$element, function () { return new lightSwitchApplication.BrowseWorklistItems().findContentItem("Person2"); }]
    });

    lightSwitchApplication.NewWorklistItem.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.NewWorklistItem
        },
        Group: {
            _$class: msls.ContentItem,
            _$name: "Group",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        WorklistItem_Organization: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_Organization",
            _$parentName: "Group",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Organization
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "WorklistItem_Organization",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Organization,
            value: lightSwitchApplication.Organization
        },
        WorklistItem_Name: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_Name",
            _$parentName: "Group",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: String
        },
        WorklistItem_Description: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_Description",
            _$parentName: "Group",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: String
        },
        Step2: {
            _$class: msls.ContentItem,
            _$name: "Step2",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        WorklistItem_Area: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_Area",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Area
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "WorklistItem_Area",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        WorklistItem_Environment: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_Environment",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Environment
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "WorklistItem_Environment",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        WorklistItem_StatusSet: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_StatusSet",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.StatusSet
        },
        StatusSet: {
            _$class: msls.ContentItem,
            _$name: "StatusSet",
            _$parentName: "WorklistItem_StatusSet",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.StatusSet
        },
        WorklistItem_Person: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_Person",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.Person
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "WorklistItem_Person",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        WorklistItem_StartDate: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_StartDate",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: Date
        },
        WorklistItem_EndDate: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem_EndDate",
            _$parentName: "Step2",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: Date
        },
        Step3: {
            _$class: msls.ContentItem,
            _$name: "Step3",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.NewWorklistItem
        },
        WorklistItem: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem",
            _$parentName: "Step3",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.NewWorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        StartDate: {
            _$class: msls.ContentItem,
            _$name: "StartDate",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        EndDate: {
            _$class: msls.ContentItem,
            _$name: "EndDate",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        Area1: {
            _$class: msls.ContentItem,
            _$name: "Area1",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Area
        },
        StatusSet1: {
            _$class: msls.ContentItem,
            _$name: "StatusSet1",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.StatusSet
        },
        Environment1: {
            _$class: msls.ContentItem,
            _$name: "Environment1",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        Organization1: {
            _$class: msls.ContentItem,
            _$name: "Organization1",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Organization
        },
        Person1: {
            _$class: msls.ContentItem,
            _$name: "Person1",
            _$parentName: "WorklistItem",
            screen: lightSwitchApplication.NewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Person
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.NewWorklistItem
        }
    };

    msls._addEntryPoints(lightSwitchApplication.NewWorklistItem, {
        /// <field>
        /// Called when a new NewWorklistItem screen is created.
        /// <br/>created(msls.application.NewWorklistItem screen)
        /// </field>
        created: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called before changes on an active NewWorklistItem screen are applied.
        /// <br/>beforeApplyChanges(msls.application.NewWorklistItem screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to determine if the ShowStep2 method can be executed.
        /// <br/>canExecute(msls.application.NewWorklistItem screen)
        /// </field>
        ShowStep2_canExecute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to execute the ShowStep2 method.
        /// <br/>execute(msls.application.NewWorklistItem screen)
        /// </field>
        ShowStep2_execute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to determine if the ShowStep3 method can be executed.
        /// <br/>canExecute(msls.application.NewWorklistItem screen)
        /// </field>
        ShowStep3_canExecute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to execute the ShowStep3 method.
        /// <br/>execute(msls.application.NewWorklistItem screen)
        /// </field>
        ShowStep3_execute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to determine if the Finish method can be executed.
        /// <br/>canExecute(msls.application.NewWorklistItem screen)
        /// </field>
        Finish_canExecute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called to execute the Finish method.
        /// <br/>execute(msls.application.NewWorklistItem screen)
        /// </field>
        Finish_execute: [lightSwitchApplication.NewWorklistItem],
        /// <field>
        /// Called after the Group content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Group"); }],
        /// <field>
        /// Called after the WorklistItem_Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_Organization_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_Organization"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Organization"); }],
        /// <field>
        /// Called after the WorklistItem_Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_Name_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_Name"); }],
        /// <field>
        /// Called after the WorklistItem_Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_Description_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_Description"); }],
        /// <field>
        /// Called after the Step2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Step2_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Step2"); }],
        /// <field>
        /// Called after the WorklistItem_Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_Area_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_Area"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Area"); }],
        /// <field>
        /// Called after the WorklistItem_Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_Environment_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_Environment"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Environment"); }],
        /// <field>
        /// Called after the WorklistItem_StatusSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_StatusSet_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_StatusSet"); }],
        /// <field>
        /// Called after the StatusSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("StatusSet"); }],
        /// <field>
        /// Called after the WorklistItem_Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_Person_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_Person"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Person"); }],
        /// <field>
        /// Called after the WorklistItem_StartDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_StartDate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_StartDate"); }],
        /// <field>
        /// Called after the WorklistItem_EndDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_EndDate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem_EndDate"); }],
        /// <field>
        /// Called after the Step3 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Step3_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Step3"); }],
        /// <field>
        /// Called after the WorklistItem content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("WorklistItem"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Name"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Description"); }],
        /// <field>
        /// Called after the StartDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StartDate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("StartDate"); }],
        /// <field>
        /// Called after the EndDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EndDate_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("EndDate"); }],
        /// <field>
        /// Called after the Area1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Area1"); }],
        /// <field>
        /// Called after the StatusSet1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("StatusSet1"); }],
        /// <field>
        /// Called after the Environment1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Environment1"); }],
        /// <field>
        /// Called after the Organization1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Organization1"); }],
        /// <field>
        /// Called after the Person1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person1_postRender: [$element, function () { return new lightSwitchApplication.NewWorklistItem().findContentItem("Person1"); }]
    });

    lightSwitchApplication.ViewWorklistItem.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewWorklistItem
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.ViewWorklistItem,
            value: lightSwitchApplication.ViewWorklistItem
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.ViewWorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        StartDate: {
            _$class: msls.ContentItem,
            _$name: "StartDate",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        EndDate: {
            _$class: msls.ContentItem,
            _$name: "EndDate",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Area
        },
        StatusSet: {
            _$class: msls.ContentItem,
            _$name: "StatusSet",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.StatusSet
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        Organization: {
            _$class: msls.ContentItem,
            _$name: "Organization",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Organization
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Person
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        LogEntries: {
            _$class: msls.ContentItem,
            _$name: "LogEntries",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.LogEntry
                }
            }
        },
        LogEntriesTemplate: {
            _$class: msls.ContentItem,
            _$name: "LogEntriesTemplate",
            _$parentName: "LogEntries",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogEntry
        },
        Entry: {
            _$class: msls.ContentItem,
            _$name: "Entry",
            _$parentName: "LogEntriesTemplate",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        Created1: {
            _$class: msls.ContentItem,
            _$name: "Created1",
            _$parentName: "LogEntriesTemplate",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: Date
        },
        Tickets: {
            _$class: msls.ContentItem,
            _$name: "Tickets",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.ViewWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.Ticket
                }
            }
        },
        TicketsTemplate: {
            _$class: msls.ContentItem,
            _$name: "TicketsTemplate",
            _$parentName: "Tickets",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketType: {
            _$class: msls.ContentItem,
            _$name: "TicketType",
            _$parentName: "TicketsTemplate",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.TicketType
        },
        TicketNumber: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber",
            _$parentName: "TicketsTemplate",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        DateCreated: {
            _$class: msls.ContentItem,
            _$name: "DateCreated",
            _$parentName: "TicketsTemplate",
            screen: lightSwitchApplication.ViewWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewWorklistItem
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewWorklistItem, {
        /// <field>
        /// Called when a new ViewWorklistItem screen is created.
        /// <br/>created(msls.application.ViewWorklistItem screen)
        /// </field>
        created: [lightSwitchApplication.ViewWorklistItem],
        /// <field>
        /// Called before changes on an active ViewWorklistItem screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewWorklistItem screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewWorklistItem],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Name"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Description"); }],
        /// <field>
        /// Called after the StartDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StartDate_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("StartDate"); }],
        /// <field>
        /// Called after the EndDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EndDate_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("EndDate"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Created"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Area"); }],
        /// <field>
        /// Called after the StatusSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("StatusSet"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Environment"); }],
        /// <field>
        /// Called after the Organization content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Organization_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Organization"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Person"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("right"); }],
        /// <field>
        /// Called after the LogEntries content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntries_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("LogEntries"); }],
        /// <field>
        /// Called after the LogEntriesTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntriesTemplate_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("LogEntriesTemplate"); }],
        /// <field>
        /// Called after the Entry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Entry_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Entry"); }],
        /// <field>
        /// Called after the Created1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created1_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Created1"); }],
        /// <field>
        /// Called after the Tickets content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Tickets_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("Tickets"); }],
        /// <field>
        /// Called after the TicketsTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketsTemplate_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("TicketsTemplate"); }],
        /// <field>
        /// Called after the TicketType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("TicketType"); }],
        /// <field>
        /// Called after the TicketNumber content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("TicketNumber"); }],
        /// <field>
        /// Called after the DateCreated content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated_postRender: [$element, function () { return new lightSwitchApplication.ViewWorklistItem().findContentItem("DateCreated"); }]
    });

    lightSwitchApplication.AddEditLogEntry.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditLogEntry
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.AddEditLogEntry,
            value: lightSwitchApplication.AddEditLogEntry
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.AddEditLogEntry,
            value: lightSwitchApplication.LogEntry
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogEntry
        },
        Entry: {
            _$class: msls.ContentItem,
            _$name: "Entry",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        LogType: {
            _$class: msls.ContentItem,
            _$name: "LogType",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogType
        },
        LogTypeTemplate: {
            _$class: msls.ContentItem,
            _$name: "LogTypeTemplate",
            _$parentName: "LogType",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.LogType,
            value: lightSwitchApplication.LogType
        },
        WorklistItem: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditLogEntry,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.WorklistItem
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditLogEntry
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditLogEntry, {
        /// <field>
        /// Called when a new AddEditLogEntry screen is created.
        /// <br/>created(msls.application.AddEditLogEntry screen)
        /// </field>
        created: [lightSwitchApplication.AddEditLogEntry],
        /// <field>
        /// Called before changes on an active AddEditLogEntry screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditLogEntry screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditLogEntry],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("left"); }],
        /// <field>
        /// Called after the Entry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Entry_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("Entry"); }],
        /// <field>
        /// Called after the LogType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogType_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("LogType"); }],
        /// <field>
        /// Called after the LogTypeTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogTypeTemplate_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("LogTypeTemplate"); }],
        /// <field>
        /// Called after the WorklistItem content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogEntry().findContentItem("WorklistItem"); }]
    });

    lightSwitchApplication.AddEditTicket.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditTicket
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.AddEditTicket,
            value: lightSwitchApplication.AddEditTicket
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.AddEditTicket,
            value: lightSwitchApplication.Ticket
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketNumber: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        TicketType: {
            _$class: msls.ContentItem,
            _$name: "TicketType",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.TicketType
        },
        RowTemplate: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate",
            _$parentName: "TicketType",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.TicketType,
            value: lightSwitchApplication.TicketType
        },
        DateCreated: {
            _$class: msls.ContentItem,
            _$name: "DateCreated",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.Ticket,
            value: String
        },
        WorklistItem: {
            _$class: msls.ContentItem,
            _$name: "WorklistItem",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditTicket,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.WorklistItem
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditTicket
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditTicket, {
        /// <field>
        /// Called when a new AddEditTicket screen is created.
        /// <br/>created(msls.application.AddEditTicket screen)
        /// </field>
        created: [lightSwitchApplication.AddEditTicket],
        /// <field>
        /// Called before changes on an active AddEditTicket screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditTicket screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditTicket],
        /// <field>
        /// Called to determine if the DeleteTicket method can be executed.
        /// <br/>canExecute(msls.application.AddEditTicket screen)
        /// </field>
        DeleteTicket_canExecute: [lightSwitchApplication.AddEditTicket],
        /// <field>
        /// Called to execute the DeleteTicket method.
        /// <br/>execute(msls.application.AddEditTicket screen)
        /// </field>
        DeleteTicket_execute: [lightSwitchApplication.AddEditTicket],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("left"); }],
        /// <field>
        /// Called after the TicketNumber content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("TicketNumber"); }],
        /// <field>
        /// Called after the TicketType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("TicketType"); }],
        /// <field>
        /// Called after the RowTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("RowTemplate"); }],
        /// <field>
        /// Called after the DateCreated content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("DateCreated"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("Description"); }],
        /// <field>
        /// Called after the WorklistItem content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        WorklistItem_postRender: [$element, function () { return new lightSwitchApplication.AddEditTicket().findContentItem("WorklistItem"); }]
    });

    lightSwitchApplication.AddEditLogType.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditLogType
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.AddEditLogType,
            value: lightSwitchApplication.AddEditLogType
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.AddEditLogType,
            value: lightSwitchApplication.LogType
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.LogType,
            value: lightSwitchApplication.LogType
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditLogType,
            data: lightSwitchApplication.LogType,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditLogType
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditLogType, {
        /// <field>
        /// Called when a new AddEditLogType screen is created.
        /// <br/>created(msls.application.AddEditLogType screen)
        /// </field>
        created: [lightSwitchApplication.AddEditLogType],
        /// <field>
        /// Called before changes on an active AddEditLogType screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditLogType screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditLogType],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditLogType().findContentItem("Name"); }]
    });

    lightSwitchApplication.AddEditWorklistItem.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditWorklistItem
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.AddEditWorklistItem,
            value: lightSwitchApplication.AddEditWorklistItem
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.AddEditWorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.WorklistItem
        },
        Name: {
            _$class: msls.ContentItem,
            _$name: "Name",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        Description: {
            _$class: msls.ContentItem,
            _$name: "Description",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: String
        },
        StatusSet: {
            _$class: msls.ContentItem,
            _$name: "StatusSet",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.StatusSet
        },
        RowTemplate1: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate1",
            _$parentName: "StatusSet",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.StatusSet,
            value: lightSwitchApplication.StatusSet
        },
        Tickets1: {
            _$class: msls.ContentItem,
            _$name: "Tickets1",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.AddEditWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.Ticket
                }
            }
        },
        rows1: {
            _$class: msls.ContentItem,
            _$name: "rows1",
            _$parentName: "Tickets1",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.Ticket
        },
        TicketType: {
            _$class: msls.ContentItem,
            _$name: "TicketType",
            _$parentName: "rows1",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: lightSwitchApplication.TicketType
        },
        TicketNumber: {
            _$class: msls.ContentItem,
            _$name: "TicketNumber",
            _$parentName: "rows1",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Number
        },
        DateCreated: {
            _$class: msls.ContentItem,
            _$name: "DateCreated",
            _$parentName: "rows1",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Ticket,
            value: Date
        },
        LogEntries1: {
            _$class: msls.ContentItem,
            _$name: "LogEntries1",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.AddEditWorklistItem,
                _$entry: {
                    elementType: lightSwitchApplication.LogEntry
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "LogEntries1",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: lightSwitchApplication.LogEntry
        },
        Entry: {
            _$class: msls.ContentItem,
            _$name: "Entry",
            _$parentName: "rows",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "rows",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.LogEntry,
            value: Date
        },
        Person: {
            _$class: msls.ContentItem,
            _$name: "Person",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Person
        },
        RowTemplate4: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate4",
            _$parentName: "Person",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Person,
            value: lightSwitchApplication.Person
        },
        Environment: {
            _$class: msls.ContentItem,
            _$name: "Environment",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Environment
        },
        RowTemplate2: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate2",
            _$parentName: "Environment",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Environment,
            value: lightSwitchApplication.Environment
        },
        Area: {
            _$class: msls.ContentItem,
            _$name: "Area",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: lightSwitchApplication.Area
        },
        RowTemplate: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate",
            _$parentName: "Area",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.Area,
            value: lightSwitchApplication.Area
        },
        StartDate: {
            _$class: msls.ContentItem,
            _$name: "StartDate",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        EndDate: {
            _$class: msls.ContentItem,
            _$name: "EndDate",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditWorklistItem,
            data: lightSwitchApplication.WorklistItem,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditWorklistItem
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditWorklistItem, {
        /// <field>
        /// Called when a new AddEditWorklistItem screen is created.
        /// <br/>created(msls.application.AddEditWorklistItem screen)
        /// </field>
        created: [lightSwitchApplication.AddEditWorklistItem],
        /// <field>
        /// Called before changes on an active AddEditWorklistItem screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditWorklistItem screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditWorklistItem],
        /// <field>
        /// Called to determine if the DeleteThisWorklist method can be executed.
        /// <br/>canExecute(msls.application.AddEditWorklistItem screen)
        /// </field>
        DeleteThisWorklist_canExecute: [lightSwitchApplication.AddEditWorklistItem],
        /// <field>
        /// Called to execute the DeleteThisWorklist method.
        /// <br/>execute(msls.application.AddEditWorklistItem screen)
        /// </field>
        DeleteThisWorklist_execute: [lightSwitchApplication.AddEditWorklistItem],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("left"); }],
        /// <field>
        /// Called after the Name content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Name_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Name"); }],
        /// <field>
        /// Called after the Description content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Description_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Description"); }],
        /// <field>
        /// Called after the StatusSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StatusSet_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("StatusSet"); }],
        /// <field>
        /// Called after the RowTemplate1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate1_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("RowTemplate1"); }],
        /// <field>
        /// Called after the Tickets1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Tickets1_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Tickets1"); }],
        /// <field>
        /// Called after the rows1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows1_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("rows1"); }],
        /// <field>
        /// Called after the TicketType content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketType_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("TicketType"); }],
        /// <field>
        /// Called after the TicketNumber content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        TicketNumber_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("TicketNumber"); }],
        /// <field>
        /// Called after the DateCreated content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        DateCreated_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("DateCreated"); }],
        /// <field>
        /// Called after the LogEntries1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        LogEntries1_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("LogEntries1"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("rows"); }],
        /// <field>
        /// Called after the Entry content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Entry_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Entry"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Created"); }],
        /// <field>
        /// Called after the Person content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Person_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Person"); }],
        /// <field>
        /// Called after the RowTemplate4 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate4_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("RowTemplate4"); }],
        /// <field>
        /// Called after the Environment content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Environment_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Environment"); }],
        /// <field>
        /// Called after the RowTemplate2 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate2_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("RowTemplate2"); }],
        /// <field>
        /// Called after the Area content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Area_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("Area"); }],
        /// <field>
        /// Called after the RowTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("RowTemplate"); }],
        /// <field>
        /// Called after the StartDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        StartDate_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("StartDate"); }],
        /// <field>
        /// Called after the EndDate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        EndDate_postRender: [$element, function () { return new lightSwitchApplication.AddEditWorklistItem().findContentItem("EndDate"); }]
    });

}(msls.application));