﻿/// <reference path="data.js" />

(function (lightSwitchApplication) {

    msls._addEntryPoints(lightSwitchApplication.Area, {
        /// <field>
        /// Called when a new area is created.
        /// <br/>created(msls.application.Area entity)
        /// </field>
        created: [lightSwitchApplication.Area]
    });

    msls._addEntryPoints(lightSwitchApplication.Environment, {
        /// <field>
        /// Called when a new environment is created.
        /// <br/>created(msls.application.Environment entity)
        /// </field>
        created: [lightSwitchApplication.Environment]
    });

    msls._addEntryPoints(lightSwitchApplication.LogEntry, {
        /// <field>
        /// Called when a new logEntry is created.
        /// <br/>created(msls.application.LogEntry entity)
        /// </field>
        created: [lightSwitchApplication.LogEntry]
    });

    msls._addEntryPoints(lightSwitchApplication.LogType, {
        /// <field>
        /// Called when a new logType is created.
        /// <br/>created(msls.application.LogType entity)
        /// </field>
        created: [lightSwitchApplication.LogType]
    });

    msls._addEntryPoints(lightSwitchApplication.Organization, {
        /// <field>
        /// Called when a new organization is created.
        /// <br/>created(msls.application.Organization entity)
        /// </field>
        created: [lightSwitchApplication.Organization]
    });

    msls._addEntryPoints(lightSwitchApplication.Person, {
        /// <field>
        /// Called when a new person is created.
        /// <br/>created(msls.application.Person entity)
        /// </field>
        created: [lightSwitchApplication.Person]
    });

    msls._addEntryPoints(lightSwitchApplication.StatusSet, {
        /// <field>
        /// Called when a new statusSet is created.
        /// <br/>created(msls.application.StatusSet entity)
        /// </field>
        created: [lightSwitchApplication.StatusSet]
    });

    msls._addEntryPoints(lightSwitchApplication.Ticket, {
        /// <field>
        /// Called when a new ticket is created.
        /// <br/>created(msls.application.Ticket entity)
        /// </field>
        created: [lightSwitchApplication.Ticket]
    });

    msls._addEntryPoints(lightSwitchApplication.TicketType, {
        /// <field>
        /// Called when a new ticketType is created.
        /// <br/>created(msls.application.TicketType entity)
        /// </field>
        created: [lightSwitchApplication.TicketType]
    });

    msls._addEntryPoints(lightSwitchApplication.WorklistItem, {
        /// <field>
        /// Called when a new worklistItem is created.
        /// <br/>created(msls.application.WorklistItem entity)
        /// </field>
        created: [lightSwitchApplication.WorklistItem]
    });

}(msls.application));
